from django.db import models


class Value(models.Model):
    """
    Barcha modullar (1, 2, 3, 4) shu markazlashtirilgan ro'yxatga tugma orqali
    bog'lanadi — erkin matn emas. Bu "mehr-oqibat" va "Mehr-oqibat" kabi
    nomuvofiqliklar tufayli Qadriyat sikli bog'lanishlarining sinishini oldini oladi.
    """

    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True)
    description = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "Values"

    def __str__(self):
        return self.name
