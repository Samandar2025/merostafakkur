from django.apps import AppConfig


class ValuesappConfig(AppConfig):
    name = 'valuesapp'
