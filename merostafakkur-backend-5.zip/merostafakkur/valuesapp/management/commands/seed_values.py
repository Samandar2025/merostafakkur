from django.core.management.base import BaseCommand
from django.utils.text import slugify

from valuesapp.models import Value

# 3-modul hujjatidagi 10 ta qadriyat + 1 va 2-modullarda allaqachon ishlatilgan qadriyatlar
VALUES = [
    "Mehr-oqibat", "Kattalarga hurmat", "Mehnatsevarlik", "Tejamkorlik",
    "Hamjihatlik", "Tabiatga g'amxo'rlik", "Mas'uliyat", "Do'stlik",
    "Ne'matni qadrlash", "Obodonchilik",
    # 1 va 2-modul kontentida ishlatilgan qo'shimcha qadriyatlar
    "Halollik", "Saxovat", "Qo'shnichilik", "Bag'rikenglik", "Adolat",
    "Hamkorlik", "Javobgarlik",
]


class Command(BaseCommand):
    help = "Markazlashtirilgan Value ro'yxatini bazaga kiritadi"

    def handle(self, *args, **options):
        for name in VALUES:
            obj, created = Value.objects.get_or_create(
                name=name, defaults={"slug": slugify(name)},
            )
            mark = "✓" if created else "· (mavjud)"
            self.stdout.write(f"  {mark} {name}")
        self.stdout.write(self.style.SUCCESS(f"\n{len(VALUES)} ta qadriyat tayyor."))
