from django.contrib import admin

from .models import Value


@admin.register(Value)
class ValueAdmin(admin.ModelAdmin):
    list_display = ["name", "slug", "description"]
    prepopulated_fields = {"slug": ("name",)}
    search_fields = ["name"]
