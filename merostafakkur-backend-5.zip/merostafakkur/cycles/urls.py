from django.urls import path

from . import views

app_name = "cycles"

urlpatterns = [
    path("rewards/", views.MyRewardsView.as_view(), name="my-rewards"),
    path("rewards/<int:reward_id>/claim/", views.ClaimRewardView.as_view(), name="claim-reward"),
]
