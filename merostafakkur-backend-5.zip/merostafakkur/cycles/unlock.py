import random

from .models import CycleReward, ValueCycle
from .wisdom import random_wisdom


def _is_part_completed(student, cycle, part_field, submission_related_name):
    """
    Sikldagi bitta qism (masalan heritage_material) mavjud bo'lmasa — talab qilinmaydi.
    Mavjud bo'lsa — o'sha qism uchun shu o'quvchining 'completed' submission'i borligini tekshiradi.
    """
    part = getattr(cycle, part_field)
    if part is None:
        return True  # bu qism sikldan umuman yo'q — talab qilinmaydi
    submissions = getattr(cycle, submission_related_name)
    return submissions.filter(student=student, status="completed").exists()


def is_cycle_completed_by_student(student, cycle):
    return (
        _is_part_completed(student, cycle, "heritage_material", "value_analysis_submissions")
        and _is_part_completed(student, cycle, "dilemma", "moral_choice_submissions")
        and _is_part_completed(student, cycle, "kindness_task", "kindness_submissions")
        and cycle.completeness() > 0  # bo'sh sikl uchun mukofot berilmaydi
    )


def check_and_unlock_reward(student, cycle):
    """
    Agar sikl shu o'quvchi tomonidan endi to'liq tugatilgan bo'lsa va hali
    mukofot berilmagan bo'lsa — yangi CycleReward yaratadi.
    """
    if CycleReward.objects.filter(student=student, cycle=cycle).exists():
        return None  # bu sikl uchun mukofot allaqachon berilgan

    if not is_cycle_completed_by_student(student, cycle):
        return None

    reward_type = random.choice(CycleReward.RewardType.values)
    return CycleReward.objects.create(
        student=student,
        cycle=cycle,
        reward_type=reward_type,
        wisdom_text=random_wisdom() if reward_type == CycleReward.RewardType.WISDOM_CARD else "",
    )


def check_all_cycles_for_student(student):
    """Bitta submission ko'p sikllarga tegishli bo'lmasa ham, xavfsizlik uchun barcha sikllarni tekshiradi."""
    created = []
    for cycle in ValueCycle.objects.all():
        reward = check_and_unlock_reward(student, cycle)
        if reward:
            created.append(reward)
    return created
