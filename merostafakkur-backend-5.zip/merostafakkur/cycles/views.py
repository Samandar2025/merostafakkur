from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import CycleReward
from .serializers import CycleRewardSerializer


class IsStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_student())


class MyRewardsView(APIView):
    """O'quvchining barcha ochilgan mukofotlari — yangilari (claimed_at=None) tepada."""

    permission_classes = [IsStudent]

    def get(self, request):
        rewards = CycleReward.objects.filter(student=request.user)
        return Response(CycleRewardSerializer(rewards, many=True).data)


class ClaimRewardView(APIView):
    """Bola xazinani ochib ko'rganda chaqiriladi — animatsiya bir marta ko'rsatilishi uchun."""

    permission_classes = [IsStudent]

    def post(self, request, reward_id):
        reward = get_object_or_404(CycleReward, id=reward_id, student=request.user)
        if reward.claimed_at is None:
            reward.claimed_at = timezone.now()
            reward.save(update_fields=["claimed_at"])
        return Response(CycleRewardSerializer(reward).data)
