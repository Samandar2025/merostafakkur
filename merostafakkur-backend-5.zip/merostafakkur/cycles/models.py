from django.conf import settings
from django.db import models

from valuesapp.models import Value


class ValueCycle(models.Model):
    """
    Bitta qadriyat atrofida 1, 2 va 3-modul kontentini qat'iy bog'laydi:
    rivoyat (anglash) -> vaziyat (qaror) -> amaliy topshiriq (xatti-harakat).

    Uchala maydon ham ixtiyoriy (null=True) — sikl to'liq bo'lmasa ham
    (masalan, hali mos rivoyat yozilmagan bo'lsa) qisman ishlatilishi mumkin.
    """

    value = models.ForeignKey(Value, on_delete=models.PROTECT, related_name="cycles")
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)

    heritage_material = models.ForeignKey(
        "heritage.HeritageMaterial", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cycles",
    )
    dilemma = models.ForeignKey(
        "dilemmas.MoralDilemma", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cycles",
    )
    kindness_task = models.ForeignKey(
        "kindness.KindnessTask", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cycles",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.value.name})"

    def completeness(self):
        """Sikl nechta bosqichdan iborat ekanini ko'rsatadi (0-3) — hisobot uchun qulay."""
        return sum([
            self.heritage_material_id is not None,
            self.dilemma_id is not None,
            self.kindness_task_id is not None,
        ])


class CycleReward(models.Model):
    """
    O'quvchi bitta Qadriyat siklini (unga tegishli barcha mavjud qismlarni)
    to'liq tugatganda avtomatik yaratiladigan mukofot. "Shoshilib bajarish"
    xavfini kamaytirish uchun mukofot HAR BIR SIKLDAN KEYIN (kichik-kichik),
    yakuniy natijadan emas.
    """

    class RewardType(models.TextChoices):
        MEMORY_GAME = "memory_game", "Milliy naqsh xotira o'yini"
        WISDOM_CARD = "wisdom_card", "Hikmatli so'z kartochkasi"

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="cycle_rewards",
    )
    cycle = models.ForeignKey(ValueCycle, on_delete=models.CASCADE, related_name="rewards")
    reward_type = models.CharField(max_length=20, choices=RewardType.choices)
    wisdom_text = models.CharField(max_length=255, blank=True, help_text="Faqat wisdom_card uchun")

    unlocked_at = models.DateTimeField(auto_now_add=True)
    claimed_at = models.DateTimeField(null=True, blank=True, help_text="Bola ochib ko'rgan payt")

    class Meta:
        unique_together = ("student", "cycle")
        ordering = ["-unlocked_at"]

    def __str__(self):
        return f"{self.student} — {self.cycle.title} ({self.get_reward_type_display()})"
