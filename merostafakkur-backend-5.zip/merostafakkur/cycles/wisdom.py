import random

WISDOM_QUOTES = [
    "Yaxshilik qil, ko'lga tashla — baliq bilar, baliq bilmasa, Xolik bilar.",
    "Do'st boshga kun tushganda tanilar.",
    "Bilim — behad boylik, undan xech kim mahrum bo'lmasin.",
    "Ona yurting — oltin beshiging.",
    "Mehnat bilan er ko'karar.",
    "Kichkina bo'lsa ham, o'z ishing — buyuk ish.",
    "Ko'p bilgan ko'p yashaydi.",
    "Yaxshi so'z — jon ozig'i.",
    "Aql bilan yurgan aslo yo'ldan adashmas.",
    "Vatanni sevmoq — imondandir.",
    "Har kimning oz-oz yaxshiligi — katta baxt.",
    "Kattaga hurmat — o'zingga qut.",
]


def random_wisdom():
    return random.choice(WISDOM_QUOTES)
