from rest_framework import serializers

from .models import CycleReward


class CycleRewardSerializer(serializers.ModelSerializer):
    cycle_title = serializers.CharField(source="cycle.title", read_only=True)
    value_name = serializers.CharField(source="cycle.value.name", read_only=True)

    class Meta:
        model = CycleReward
        fields = [
            "id", "cycle_title", "value_name", "reward_type", "wisdom_text",
            "unlocked_at", "claimed_at",
        ]
        read_only_fields = fields
