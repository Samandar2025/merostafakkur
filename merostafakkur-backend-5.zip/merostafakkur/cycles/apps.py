from django.apps import AppConfig


class CyclesConfig(AppConfig):
    name = 'cycles'

    def ready(self):
        from . import signals  # noqa: F401
