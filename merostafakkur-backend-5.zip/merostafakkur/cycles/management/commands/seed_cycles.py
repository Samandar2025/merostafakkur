from django.core.management.base import BaseCommand

from cycles.models import ValueCycle
from dilemmas.models import MoralDilemma
from kindness.models import KindnessTask
from valuesapp.models import Value


class Command(BaseCommand):
    help = "Namuna Qadriyat siklini yaratadi: 'Keksa qo'shnimiz' vaziyati + 'Mehr-oqibat' topshirig'i"

    def handle(self, *args, **options):
        try:
            value = Value.objects.get(name="Mehr-oqibat")
        except Value.DoesNotExist:
            self.stderr.write(self.style.ERROR("Avval 'seed_values' ni ishga tushiring."))
            return

        dilemma = MoralDilemma.objects.filter(title="Keksa qo'shnimiz").first()
        task = KindnessTask.objects.filter(value=value).first()

        if not dilemma:
            self.stderr.write(self.style.WARNING(
                "'Keksa qo'shnimiz' vaziyati topilmadi — avval 'seed_dilemmas' ni ishga tushiring."
            ))
        if not task:
            self.stderr.write(self.style.WARNING(
                "Mehr-oqibat topshirig'i topilmadi — avval 'seed_kindness_tasks' ni ishga tushiring."
            ))

        cycle, created = ValueCycle.objects.update_or_create(
            title="Mehr-oqibat sikli: Qo'shniga yordam",
            defaults=dict(
                value=value,
                description=(
                    "2-modulda o'quvchi keksa qo'shniga yordam berish vaziyatida qaror qabul "
                    "qiladi; 3-modulda ayni qadriyatni real hayotda amalga oshiradi."
                ),
                heritage_material=None,  # hali mos rivoyat yozilmagan — sikl 2/3 to'liq
                dilemma=dilemma,
                kindness_task=task,
            ),
        )
        mark = "yaratildi" if created else "yangilandi"
        self.stdout.write(self.style.SUCCESS(
            f"Sikl {mark}: '{cycle.title}' — to'liqligi: {cycle.completeness()}/3"
        ))
        if cycle.completeness() < 3:
            self.stdout.write(
                "  (Eslatma: hali 'Mehr-oqibat' qadriyatiga mos rivoyat (1-modul) yozilmagan — "
                "sikl shu qismi bo'yicha to'liq emas, lekin bu normal holat.)"
            )
