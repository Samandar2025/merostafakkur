from django.core.management.base import BaseCommand
from rest_framework.test import APIRequestFactory, force_authenticate

from accounts.models import User
from cycles.models import CycleReward, ValueCycle
from cycles.views import MyRewardsView, ClaimRewardView
from dilemmas.views import ChooseOptionView, StartOrResumeMoralChoiceView, SubmitJustificationView, SubmitOutcomeView
from kindness.views import CommitView, StartOrResumeKindnessView, SubmitQ1View, SubmitQ2View, SubmitQ3View


class Command(BaseCommand):
    help = "Sikl to'liq bajarilganda mukofot avtomatik ochilishini sinaydi"

    def handle(self, *args, **options):
        student, _ = User.objects.get_or_create(
            username="test_student_reward", defaults={"role": User.Role.STUDENT}
        )
        cycle = ValueCycle.objects.get(title="Mehr-oqibat sikli: Qo'shniga yordam")
        factory = APIRequestFactory()

        def call(view_cls, method_name, path, data, user, **kwargs):
            req = getattr(factory, method_name)(path, data, format="json")
            force_authenticate(req, user=user)
            return view_cls.as_view()(req, **kwargs)

        self.stdout.write(f"Sikl: '{cycle.title}' (to'liqligi: {cycle.completeness()}/3 — material yo'q, faqat dilemma+task)")

        # ---- 2-modulni (dilemma) bajarib, submission'ni siklga bog'laymiz ----
        self.stdout.write("\n1) 2-modul (dilemma) bajarilmoqda...")
        resp = call(StartOrResumeMoralChoiceView, "post", "/start/", {}, student, dilemma_id=cycle.dilemma_id)
        dsid = resp.data["id"]
        # Bu yerda submission'ni siklga qo'lda bog'laymiz (kelajakda Assignment orqali avtomatik bo'ladi)
        from dilemmas.models import MoralChoiceSubmission
        MoralChoiceSubmission.objects.filter(id=dsid).update(cycle=cycle)

        option = cycle.dilemma.options.first()
        call(ChooseOptionView, "post", "/choose/", {"option_id": option.id}, student, submission_id=dsid)
        call(SubmitJustificationView, "post", "/justify/", {"justification_text": "Chunki yordam berish kerak."}, student, submission_id=dsid)
        resp = call(SubmitOutcomeView, "post", "/outcome/", {"outcome_prediction_text": "Qo'shni xursand bo'ladi."}, student, submission_id=dsid)
        self.stdout.write(f"   dilemma holati={resp.data['status']}")

        reward_count = CycleReward.objects.filter(student=student, cycle=cycle).count()
        self.stdout.write(f"   Mukofot soni (hali 2/2 emas, faqat 1/2 bajarilgan): {reward_count}")
        assert reward_count == 0, "Mukofot vaqtidan oldin ochilib qoldi!"
        self.stdout.write("   ✓ To'g'ri: hali mukofot ochilmadi (kindness_task tugallanmagan)")

        # ---- 3-modulni (kindness) bajarib, submission'ni ham siklga bog'laymiz ----
        self.stdout.write("\n2) 3-modul (kindness) bajarilmoqda...")
        resp = call(StartOrResumeKindnessView, "post", "/start/", {}, student, task_id=cycle.kindness_task_id)
        ksid = resp.data["id"]
        from kindness.models import KindnessSubmission
        KindnessSubmission.objects.filter(id=ksid).update(cycle=cycle)

        call(CommitView, "post", "/commit/", {}, student, submission_id=ksid)
        call(SubmitQ1View, "post", "/q1/", {"text": "Buvimga yordam berdim."}, student, submission_id=ksid)
        call(SubmitQ2View, "post", "/q2/", {"text": "Buvim uchun."}, student, submission_id=ksid)
        resp = call(SubmitQ3View, "post", "/q3/", {"text": "U juda xursand bo'ldi."}, student, submission_id=ksid)
        self.stdout.write(f"   kindness holati={resp.data['status']}")

        reward = CycleReward.objects.filter(student=student, cycle=cycle).first()
        assert reward is not None, "Sikl to'liq bajarilgach mukofot ochilishi kerak edi!"
        self.stdout.write(f"   ✓ Mukofot avtomatik ochildi: turi={reward.reward_type}")
        if reward.reward_type == "wisdom_card":
            self.stdout.write(f"     Hikmatli so'z: \"{reward.wisdom_text}\"")

        # ---- Bir xil sikl uchun ikkinchi marta mukofot berilmasligini tekshirish ----
        self.stdout.write("\n3) Signalni qayta ishga tushirish (masalan boshqa submission saqlanishi)...")
        ks = KindnessSubmission.objects.get(id=ksid)
        ks.save()  # qayta save -> signal qayta ishlaydi
        count_after = CycleReward.objects.filter(student=student, cycle=cycle).count()
        assert count_after == 1, "Bitta sikl uchun ikkinchi marta mukofot berilib ketdi!"
        self.stdout.write("   ✓ Takroriy mukofot berilmadi (bitta sikl = bitta mukofot)")

        # ---- API orqali ro'yxatni va claim'ni tekshirish ----
        self.stdout.write("\n4) API: mukofotlar ro'yxati va 'claim'...")
        resp = call(MyRewardsView, "get", "/rewards/", {}, student)
        assert len(resp.data) == 1
        assert resp.data[0]["claimed_at"] is None
        self.stdout.write(f"   ✓ Ro'yxatda 1 ta yangi (ochilmagan) mukofot bor")

        resp = call(ClaimRewardView, "post", "/claim/", {}, student, reward_id=reward.id)
        assert resp.data["claimed_at"] is not None
        self.stdout.write("   ✓ Claim qilingandan keyin claimed_at to'ldi")

        self.stdout.write(self.style.SUCCESS("\nSikl mukofoti oqimi to'liq va to'g'ri ishlayapti ✅"))
