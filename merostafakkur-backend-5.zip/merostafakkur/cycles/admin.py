from django.contrib import admin

from .models import CycleReward, ValueCycle


@admin.register(CycleReward)
class CycleRewardAdmin(admin.ModelAdmin):
    list_display = ["student", "cycle", "reward_type", "unlocked_at", "claimed_at"]
    list_filter = ["reward_type"]
    readonly_fields = ["student", "cycle", "reward_type", "wisdom_text", "unlocked_at"]


@admin.register(ValueCycle)
class ValueCycleAdmin(admin.ModelAdmin):
    list_display = ["title", "value", "heritage_material", "dilemma", "kindness_task", "completeness_display"]
    list_filter = ["value"]

    @admin.display(description="To'liqlik")
    def completeness_display(self, obj):
        return f"{obj.completeness()}/3"
