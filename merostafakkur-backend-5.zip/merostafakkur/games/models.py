from django.conf import settings
from django.db import models


class GameSession(models.Model):
    """
    O'yin moduli o'ynalishi haqida yozuv — ilmiy tahlil uchun
    ("nechta bola o'ynadi, qaysi o'yinni ko'proq yoqtirdi") foydali.
    O'yinning o'zi baholanmaydi — bu shunchaki dam olish/rag'batlantirish vositasi.
    """

    class GameType(models.TextChoices):
        PUZZLE = "puzzle", "Naqsh boshqotirmasi"
        BALL_SORT = "ball_sort", "Sharlarni taxlash"

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="game_sessions",
    )
    game_type = models.CharField(max_length=20, choices=GameType.choices)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.student} — {self.get_game_type_display()}"
