from django.contrib import admin

from .models import GameSession


@admin.register(GameSession)
class GameSessionAdmin(admin.ModelAdmin):
    list_display = ["student", "game_type", "started_at", "completed_at"]
    list_filter = ["game_type"]
    readonly_fields = ["student", "game_type", "started_at"]
