from django.core.management.base import BaseCommand
from rest_framework.test import APIRequestFactory, force_authenticate

from accounts.models import User
from dilemmas.models import MoralDilemma
from dilemmas.views import ChooseOptionView, StartOrResumeMoralChoiceView, SubmitJustificationView, SubmitOutcomeView
from games.views import GameAccessView, StartGameSessionView
from heritage.models import HeritageMaterial
from heritage.views import StartOrResumeSubmissionView, SubmitAnswerView, VideoProgressView


class Command(BaseCommand):
    help = "O'yin qulfi mantig'ini sinaydi: 3 modulda kamida bittadan bajarilmaguncha yopiq"

    def handle(self, *args, **options):
        student, _ = User.objects.get_or_create(
            username="test_student_games", defaults={"role": User.Role.STUDENT}
        )
        factory = APIRequestFactory()

        def call(view_cls, method_name, path, data, user, **kwargs):
            req = getattr(factory, method_name)(path, data, format="json")
            force_authenticate(req, user=user)
            return view_cls.as_view()(req, **kwargs)

        self.stdout.write("1) Boshida o'yin qulflangan bo'lishi kerak...")
        resp = call(GameAccessView, "get", "/access/", {}, student)
        assert resp.data["unlocked"] is False
        self.stdout.write("   ✓ To'g'ri: unlocked=False")

        resp = call(StartGameSessionView, "post", "/start/", {"game_type": "puzzle"}, student)
        assert resp.status_code == 403
        self.stdout.write("   ✓ To'g'ri: sessiya boshlashga urinish 403 bilan rad etildi")

        # ---- 2-modulni bajaramiz ----
        self.stdout.write("\n2) 2-modulni bajaramiz...")
        dilemma = MoralDilemma.objects.first()
        resp = call(StartOrResumeMoralChoiceView, "post", "/start/", {}, student, dilemma_id=dilemma.id)
        sid = resp.data["id"]
        call(ChooseOptionView, "post", "/choose/", {"option_id": dilemma.options.first().id}, student, submission_id=sid)
        call(SubmitJustificationView, "post", "/justify/", {"justification_text": "Sabab."}, student, submission_id=sid)
        call(SubmitOutcomeView, "post", "/outcome/", {"outcome_prediction_text": "Oqibat."}, student, submission_id=sid)

        resp = call(GameAccessView, "get", "/access/", {}, student)
        assert resp.data["unlocked"] is False
        self.stdout.write("   ✓ Hali qulflangan (faqat 1/3 modul bajarilgan)")

        # ---- 1-modulni bajaramiz ----
        self.stdout.write("\n3) 1-modulni bajaramiz...")
        material = HeritageMaterial.objects.first()
        material.video_duration_seconds = 60
        material.save()
        resp = call(StartOrResumeSubmissionView, "post", "/start/", {}, student, material_id=material.id)
        hsid = resp.data["id"]
        for sec in range(10, 61, 10):
            call(VideoProgressView, "post", "/progress/", {"progress_seconds": sec}, student, submission_id=hsid)
        for q in material.questions.order_by("display_order"):
            data = {"question_id": q.id}
            if q.question_type == "value_select":
                data["selected_value_tags"] = [material.value_tags[0]]
            else:
                data["answer_text"] = "Test javobi."
            call(SubmitAnswerView, "post", "/answer/", data, student, submission_id=hsid)

        resp = call(GameAccessView, "get", "/access/", {}, student)
        assert resp.data["unlocked"] is False
        self.stdout.write("   ✓ Hali qulflangan (2/3 modul bajarilgan, 3-modul yo'q)")

        # ---- 3-modulni bajaramiz ----
        self.stdout.write("\n4) 3-modulni bajaramiz...")
        from kindness.models import KindnessTask
        from kindness.views import CommitView, StartOrResumeKindnessView, SubmitQ1View, SubmitQ2View, SubmitQ3View
        task = KindnessTask.objects.first()
        resp = call(StartOrResumeKindnessView, "post", "/start/", {}, student, task_id=task.id)
        ksid = resp.data["id"]
        call(CommitView, "post", "/commit/", {}, student, submission_id=ksid)
        call(SubmitQ1View, "post", "/q1/", {"text": "Qildim."}, student, submission_id=ksid)
        call(SubmitQ2View, "post", "/q2/", {"text": "Kim uchun."}, student, submission_id=ksid)
        call(SubmitQ3View, "post", "/q3/", {"text": "Natija."}, student, submission_id=ksid)

        resp = call(GameAccessView, "get", "/access/", {}, student)
        assert resp.data["unlocked"] is True, "3 modul ham bajarilgach o'yin ochilishi kerak edi!"
        self.stdout.write("   ✓ Endi o'yin OCHILDI (barcha 3 modulda kamida bittadan bajarilgan)")

        resp = call(StartGameSessionView, "post", "/start/", {"game_type": "ball_sort"}, student)
        assert resp.status_code == 200
        self.stdout.write(f"   ✓ O'yin sessiyasi muvaffaqiyatli boshlandi: {resp.data}")

        self.stdout.write(self.style.SUCCESS("\nO'yin qulfi mantig'i to'liq va to'g'ri ishlayapti ✅"))
