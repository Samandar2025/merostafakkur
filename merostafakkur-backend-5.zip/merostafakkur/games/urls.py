from django.urls import path

from . import views

app_name = "games"

urlpatterns = [
    path("access/", views.GameAccessView.as_view(), name="access"),
    path("sessions/start/", views.StartGameSessionView.as_view(), name="start-session"),
    path("sessions/<int:session_id>/complete/", views.CompleteGameSessionView.as_view(), name="complete-session"),
]
