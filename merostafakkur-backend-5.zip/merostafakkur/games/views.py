from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import permissions, serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import GameSession
from .unlock import is_game_unlocked_for_student


class IsStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_student())


class GameAccessView(APIView):
    """
    O'quvchi o'yin ekranini ochishdan oldin shu yerni tekshiradi.
    unlocked=False bo'lsa, frontend qulf xabarini ko'rsatadi.
    """

    permission_classes = [IsStudent]

    def get(self, request):
        return Response({"unlocked": is_game_unlocked_for_student(request.user)})


class StartGameSessionSerializer(serializers.Serializer):
    game_type = serializers.ChoiceField(choices=GameSession.GameType.choices)


class StartGameSessionView(APIView):
    permission_classes = [IsStudent]

    def post(self, request):
        if not is_game_unlocked_for_student(request.user):
            return Response(
                {"detail": "O'yin hali qulflangan. Avval har uch modulda kamida bittadan mashqni bajaring."},
                status=status.HTTP_403_FORBIDDEN,
            )
        s = StartGameSessionSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        session = GameSession.objects.create(student=request.user, game_type=s.validated_data["game_type"])
        return Response({"id": session.id, "game_type": session.game_type})


class CompleteGameSessionView(APIView):
    permission_classes = [IsStudent]

    def post(self, request, session_id):
        session = get_object_or_404(GameSession, id=session_id, student=request.user)
        if session.completed_at is None:
            session.completed_at = timezone.now()
            session.save(update_fields=["completed_at"])
        return Response({"completed_at": session.completed_at})
