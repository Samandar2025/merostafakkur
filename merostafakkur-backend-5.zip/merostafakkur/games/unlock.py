def is_game_unlocked_for_student(student):
    """
    O'yin moduli quyidagi shart bajarilganda ochiladi:
    o'quvchi har UCH modulning (1, 2, 3) kamida bittadan mashqini
    to'liq ("completed") bajargan bo'lishi kerak. Barcha kontentni
    bajarish shart emas — bu qasddan yengil chegara (tez-tez motivatsiya
    berish, "shoshilib bajarish" xavfini oshirmaslik uchun).
    """
    from dilemmas.models import MoralChoiceSubmission
    from heritage.models import ValueAnalysisSubmission
    from kindness.models import KindnessSubmission

    has_heritage = ValueAnalysisSubmission.objects.filter(student=student, status="completed").exists()
    has_dilemma = MoralChoiceSubmission.objects.filter(student=student, status="completed").exists()
    has_kindness = KindnessSubmission.objects.filter(student=student, status="completed").exists()

    return has_heritage and has_dilemma and has_kindness
