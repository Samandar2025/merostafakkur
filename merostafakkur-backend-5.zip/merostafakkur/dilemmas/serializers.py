from rest_framework import serializers

from .models import DilemmaOption, MoralChoiceSubmission, MoralDilemma


class DilemmaOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = DilemmaOption
        fields = ["id", "option_text", "display_order"]


class MoralDilemmaSerializer(serializers.ModelSerializer):
    """
    Diqqat: variantlar bu yerda ko'rsatiladi (1-moduldagi savollardan farqli o'laroq,
    bu yerda hammasi bitta ekranda tanlanadi — yashirish shart emas).
    Lekin asoslash/oqibat matnlari uchun endpoint alohida, ketma-ketlik shu orqali ta'minlanadi.
    """

    options = DilemmaOptionSerializer(many=True, read_only=True)

    class Meta:
        model = MoralDilemma
        fields = ["id", "title", "scenario_text", "value_focus", "options",
                  "justification_prompt", "outcome_prompt"]


class MoralChoiceSubmissionSerializer(serializers.ModelSerializer):
    dilemma = MoralDilemmaSerializer(read_only=True)
    selected_option = DilemmaOptionSerializer(read_only=True)

    class Meta:
        model = MoralChoiceSubmission
        fields = [
            "id", "dilemma", "status", "selected_option",
            "justification_text", "outcome_prediction_text",
        ]
        read_only_fields = fields


class ChooseOptionSerializer(serializers.Serializer):
    option_id = serializers.IntegerField()


class JustificationSerializer(serializers.Serializer):
    justification_text = serializers.CharField()


class OutcomeSerializer(serializers.Serializer):
    outcome_prediction_text = serializers.CharField()
