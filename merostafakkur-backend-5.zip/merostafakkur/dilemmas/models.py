from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models


class MoralDilemma(models.Model):
    """Qadriyatli-muammoli vaziyat."""

    title = models.CharField(max_length=255)
    scenario_text = models.TextField()
    value_focus = models.CharField(
        max_length=255, blank=True,
        help_text="Qadriyatli yo'nalish, masalan: 'halollik, o'zgalar mulkiga hurmat'",
    )
    age_group = models.CharField(
        max_length=10,
        choices=[("1-2", "1-2 sinf"), ("3-4", "3-4 sinf")],
        default="3-4",
    )
    related_value_tags = models.JSONField(default=list, blank=True)
    justification_prompt = models.TextField(
        default="Nima uchun aynan shu yo'lni tanladingiz?",
        help_text="'Tanlovimni asoslayman' bosqichidagi savol matni",
    )
    outcome_prompt = models.TextField(
        default="Siz tanlagan yo'l amalga oshirilsa, qanday oqibat yuz berishi mumkin?",
        help_text="'Oqibatini o'ylayman' bosqichidagi savol matni",
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class DilemmaOption(models.Model):
    """Vaziyat uchun harakat varianti (A, B, C, D...). Soni moslashuvchan."""

    dilemma = models.ForeignKey(MoralDilemma, on_delete=models.CASCADE, related_name="options")
    option_text = models.TextField()
    display_order = models.PositiveIntegerField(help_text="A=1, B=2, C=3, D=4 ...")

    class Meta:
        ordering = ["dilemma", "display_order"]
        unique_together = ("dilemma", "display_order")

    def __str__(self):
        return f"{self.dilemma.title} — variant {self.display_order}"


class MoralChoiceSubmission(models.Model):
    """
    O'quvchining bitta vaziyat bo'yicha to'liq javob zanjiri:
    tanlov -> asoslash -> oqibat bashorati. Ketma-ket, orqaga qaytarib bo'lmaydi.
    """

    class Status(models.TextChoices):
        NOT_STARTED = "not_started", "Boshlanmagan"
        CHOSE = "chose", "Tanlov qilindi"
        JUSTIFIED = "justified", "Asoslandi"
        COMPLETED = "completed", "Yakunlangan"

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="moral_choice_submissions",
    )
    dilemma = models.ForeignKey(MoralDilemma, on_delete=models.CASCADE, related_name="submissions")
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="assigned_moral_choices",
    )
    cycle = models.ForeignKey(
        "cycles.ValueCycle", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="moral_choice_submissions",
    )
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NOT_STARTED)

    selected_option = models.ForeignKey(
        DilemmaOption, on_delete=models.PROTECT, null=True, blank=True,
    )
    option_chosen_at = models.DateTimeField(null=True, blank=True)

    justification_text = models.TextField(blank=True)
    justification_at = models.DateTimeField(null=True, blank=True)

    outcome_prediction_text = models.TextField(blank=True)
    outcome_predicted_at = models.DateTimeField(null=True, blank=True)

    teacher_feedback = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("student", "dilemma", "assigned_by")

    def __str__(self):
        return f"{self.student} — {self.dilemma.title} ({self.get_status_display()})"

    def choose_option(self, option: DilemmaOption):
        if self.selected_option_id is not None:
            raise ValidationError("Tanlov allaqachon qilingan — uni o'zgartirib bo'lmaydi.")
        if option.dilemma_id != self.dilemma_id:
            raise ValidationError("Variant boshqa vaziyatga tegishli.")
        from django.utils import timezone
        self.selected_option = option
        self.option_chosen_at = timezone.now()
        self.status = self.Status.CHOSE
        self.save(update_fields=["selected_option", "option_chosen_at", "status", "updated_at"])

    def submit_justification(self, text: str):
        if self.selected_option_id is None:
            raise ValidationError("Avval tanlov qilinishi kerak.")
        if self.justification_at is not None:
            raise ValidationError("Asoslash allaqachon yuborilgan.")
        if not text or not text.strip():
            raise ValidationError("Asoslash matni bo'sh bo'lishi mumkin emas.")
        from django.utils import timezone
        self.justification_text = text.strip()
        self.justification_at = timezone.now()
        self.status = self.Status.JUSTIFIED
        self.save(update_fields=["justification_text", "justification_at", "status", "updated_at"])

    def submit_outcome(self, text: str):
        if self.justification_at is None:
            raise ValidationError("Avval asoslash bosqichi bajarilishi kerak.")
        if self.outcome_predicted_at is not None:
            raise ValidationError("Oqibat bashorati allaqachon yuborilgan.")
        if not text or not text.strip():
            raise ValidationError("Oqibat bashorati bo'sh bo'lishi mumkin emas.")
        from django.utils import timezone
        self.outcome_prediction_text = text.strip()
        self.outcome_predicted_at = timezone.now()
        self.status = self.Status.COMPLETED
        self.save(update_fields=["outcome_prediction_text", "outcome_predicted_at", "status", "updated_at"])
