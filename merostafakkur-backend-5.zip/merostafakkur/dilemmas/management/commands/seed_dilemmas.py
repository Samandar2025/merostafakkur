from django.core.management.base import BaseCommand

from dilemmas.models import DilemmaOption, MoralDilemma

DILEMMAS = [
    {
        "title": "Topilgan ruchka",
        "value_focus": "halollik, o'zgalar mulkiga hurmat",
        "scenario": (
            "Tanaffusda sinfdoshingiz yo'lakdan chiroyli ruchka topib oldi. Kimniki "
            "ekanini bilmaysiz. Sinfdoshingiz: \"Hech kim ko'rmadi. O'zimizda qolsin\", dedi."
        ),
        "options": [
            "Ruchkani sinfdoshimda qoldiraman, chunki uni u topdi.",
            "Ruchkani olib, o'zim ishlataman.",
            "Egasini aniqlashga harakat qilaman, topilmasa o'qituvchiga topshiraman.",
            "Bu mening ishim emas deb, aralashmayman.",
        ],
        "justification_prompt": "Nima uchun aynan shu yo'lni tanladingiz?",
        "outcome_prompt": (
            "Siz tanlagan yo'l amalga oshirilsa, ruchka egasi, sinfdoshingiz va siz uchun "
            "qanday oqibat yuz berishi mumkin?"
        ),
        "value_tags": ["halollik", "mas'uliyat"],
    },
    {
        "title": "Do'stimga javobni aytaymi?",
        "value_focus": "halollik, do'stlik, mas'uliyat",
        "scenario": (
            "Mustaqil ish davomida yaqin do'stingiz bir savolning javobini topa olmadi. "
            "U sekingina: \"Javobni ko'rsatib yubor, hech kim bilmaydi\", dedi. Siz unga "
            "yordam berishni xohlaysiz, lekin topshiriqni har bir o'quvchi mustaqil "
            "bajarishi kerak."
        ),
        "options": [
            "Do'stim xafa bo'lmasligi uchun javobimni ko'rsataman.",
            "Javobni aytmayman va darsdan keyin mavzuni tushunishiga yordam berishni taklif qilaman.",
            "Hech narsa demay, undan yuz o'giraman.",
            "O'qituvchi ko'rmayotgan bo'lsa, javobni aytib yuboraman.",
        ],
        "justification_prompt": (
            "Nima uchun shu qarorni tanladingiz? Do'stga yordam berish bilan uning "
            "o'rniga topshiriqni bajarish o'rtasida qanday farq bor?"
        ),
        "outcome_prompt": "Siz tanlagan harakat do'stingizning keyingi o'qishiga qanday ta'sir qilishi mumkin?",
        "value_tags": ["halollik", "do'stlik", "mas'uliyat"],
    },
    {
        "title": "Yangi o'quvchi",
        "value_focus": "mehr-oqibat, do'stlik, bag'rikenglik",
        "scenario": (
            "Sinfingizga yangi o'quvchi keldi. Tanaffusda u yolg'iz turibdi. Ayrim "
            "sinfdoshlaringiz uning gapirish uslubiga kulishib: \"Uni o'yinimizga "
            "qo'shmaylik\", deyishdi. Yangi o'quvchi buni eshitdi, ammo hech narsa demadi."
        ),
        "options": [
            "Sinfdoshlarimdan ajralib qolmaslik uchun ularga qo'shilaman.",
            "Hech kim bilan tortishmasdan, vaziyatdan uzoqlashaman.",
            "Yangi o'quvchini suhbat va o'yinga taklif qilib, boshqalarga ham uni kamsitmaslikni aytaman.",
            "Faqat o'qituvchi kelgandagina vaziyat haqida gapiraman.",
        ],
        "justification_prompt": (
            "Nima uchun aynan shu harakatni tanladingiz? Qaroringizda kimlarning "
            "manfaatini hisobga oldingiz?"
        ),
        "outcome_prompt": "Sizning qaroringiz yangi o'quvchiga va sinfdagi munosabatlarga qanday ta'sir qilishi mumkin?",
        "value_tags": ["mehr-oqibat", "bag'rikenglik"],
    },
    {
        "title": "Non ortib qoldi",
        "value_focus": "tejamkorlik, ne'matni qadrlash, mas'uliyat",
        "scenario": (
            "Maktab oshxonasida tushlik qildingiz. Do'stingiz yeya oladiganidan ko'p non "
            "olgan va uning bir qismi ortib qolgan. U qolgan nonni chiqindi qutisiga "
            "tashlamoqchi."
        ),
        "options": [
            "Bu uning noni, xohlaganini qilsin deb indamayman.",
            "Men ham qolgan ovqatimni tashlayman.",
            "Uni to'xtatib, ne'matni isrof qilmaslik kerakligini aytaman va keyingi safar kerakli miqdordagina olishni taklif qilaman.",
            "Faqat oshxona xodimi ko'rsa, unga aytaman.",
        ],
        "justification_prompt": "Nima uchun shu yo'lni ma'qul deb bildingiz? Bu qaroringiz qaysi qadriyat bilan bog'liq?",
        "outcome_prompt": "Agar maktabdagi barcha o'quvchilar ovqatga shunday munosabatda bo'lsa, qanday natija yuz beradi?",
        "value_tags": ["tejamkorlik", "mas'uliyat"],
    },
    {
        "title": "Hasharda nima qilaman?",
        "value_focus": "mehnatsevarlik, hamjihatlik, jamoaviy mas'uliyat",
        "scenario": (
            "Sinfingiz maktab hovlisidagi gulzorni tartibga keltirmoqda. Har bir "
            "o'quvchiga yoshiga mos vazifa berildi. Ikki do'stingiz esa chetroqqa chiqib: "
            "\"Boshqalar bajaraveradi, biz o'ynab turamiz\", deyishdi va sizni ham "
            "chaqirishdi."
        ),
        "options": [
            "Do'stlarim bilan o'ynayman, chunki ishni boshqalar ham bajara oladi.",
            "O'zimga berilgan vazifani bajarib, do'stlarimni ham umumiy ishga qo'shilishga chaqiraman.",
            "Ishlayotgandek ko'rinib, imkon topilganda o'ynayman.",
            "Do'stlarimga hech narsa demay, faqat o'z vazifamni bajaraman.",
        ],
        "justification_prompt": (
            "Nima uchun aynan shu variantni tanladingiz? Umumiy ishda har bir kishining "
            "ishtiroki nima uchun muhim?"
        ),
        "outcome_prompt": "Agar sinfdagi ko'pchilik \"boshqalar bajaradi\" degan qarorni tanlasa, nima sodir bo'ladi?",
        "value_tags": ["mehnatsevarlik", "hamjihatlik"],
    },
    {
        "title": "Keksa qo'shnimiz",
        "value_focus": "kattalarga hurmat, mehr-oqibat, g'amxo'rlik",
        "scenario": (
            "Maktabdan qaytayotganingizda keksa qo'shningiz og'ir sumka ko'tarib "
            "kelayotganini ko'rdingiz. Shu paytda do'stlaringiz sizni futbol o'ynashga "
            "chaqirib, kutib turishibdi."
        ),
        "options": [
            "Do'stlarimni kuttirmaslik uchun tezda ularning oldiga boraman.",
            "Qo'shnim salom desa salomlashaman, ammo yordam taklif qilmayman.",
            "Do'stlarimga biroz kutishlarini aytib, qo'shnimga yordam berishni taklif qilaman.",
            "Boshqa biror kishi yordam berar deb o'ylayman.",
        ],
        "justification_prompt": "Qaror qabul qilayotganda nimalarni hisobga oldingiz?",
        "outcome_prompt": "Siz tanlagan harakat qo'shningizga, do'stlaringizga va o'zingizga qanday ta'sir qilishi mumkin?",
        "value_tags": ["kattalarga hurmat", "mehr-oqibat"],
    },
    {
        "title": "Sindirilgan nihol",
        "value_focus": "tabiatga g'amxo'rlik, javobgarlik, halollik",
        "scenario": (
            "Tanaffusda do'stlaringiz bilan o'ynayotib, ehtiyotsizlik tufayli maktab "
            "hovlisidagi yangi ekilgan niholning bir shoxini sindirib qo'ydingiz. Buni "
            "o'qituvchi ko'rmadi. Do'stingiz: \"Hech kim bilmaydi, ketaveramiz\", dedi."
        ),
        "options": [
            "Hech kim ko'rmaganligi uchun ketaman.",
            "Aybni boshqa o'quvchilarga yuklayman.",
            "Nima bo'lganini o'qituvchiga aytib, niholni saqlab qolish uchun nima qilish mumkinligini so'rayman.",
            "Singan shoxni yashirib qo'yaman.",
        ],
        "justification_prompt": "Xatoni tan olish nima uchun oson yoki qiyin bo'lishi mumkin? Sizning qaroringizga nima ta'sir qildi?",
        "outcome_prompt": "Xatoni yashirish va tan olish qanday turli oqibatlarga olib kelishi mumkin?",
        "value_tags": ["javobgarlik", "halollik"],
    },
    {
        "title": "Guruh ishida adolat",
        "value_focus": "adolat, hamkorlik, mas'uliyat",
        "scenario": (
            "To'rt o'quvchi birgalikda loyiha tayyorladingiz. Uch kishi faol ishladi, "
            "bir sinfdoshingiz esa deyarli qatnashmadi. Taqdimot oldidan u: \"O'qituvchiga "
            "hammamiz teng ishladik, deb aytamiz\", dedi."
        ),
        "options": [
            "Sinfdoshim xafa bo'lmasligi uchun rozi bo'laman.",
            "Uning umuman ishlamaganini hammaga aytib, uni ayblayman.",
            "Avval u bilan gaplashib, taqdimotning qolgan qismiga hissa qo'shishini taklif qilaman va bajarilgan ish haqida haqiqatni buzmaslikni aytaman.",
            "Bu masalaga aralashmayman.",
        ],
        "justification_prompt": "Sizningcha, do'stlik va adolat o'rtasida qanday munosabat bo'lishi kerak?",
        "outcome_prompt": "Barcha ishtirokchilar bajarmagan ishiga ham bir xil baho olsa, keyingi jamoaviy ishlarga qanday ta'sir qilishi mumkin?",
        "value_tags": ["adolat", "hamkorlik"],
    },
]


class Command(BaseCommand):
    help = "2-modul uchun barcha 8 ta muammoli vaziyatni bazaga kiritadi"

    def handle(self, *args, **options):
        for d in DILEMMAS:
            dilemma, _ = MoralDilemma.objects.update_or_create(
                title=d["title"],
                defaults=dict(
                    scenario_text=d["scenario"],
                    value_focus=d["value_focus"],
                    related_value_tags=d["value_tags"],
                    justification_prompt=d["justification_prompt"],
                    outcome_prompt=d["outcome_prompt"],
                ),
            )
            dilemma.options.all().delete()
            for i, opt_text in enumerate(d["options"], start=1):
                DilemmaOption.objects.create(dilemma=dilemma, option_text=opt_text, display_order=i)
            self.stdout.write(f"  ✓ {dilemma.title} ({len(d['options'])} variant)")

        self.stdout.write(self.style.SUCCESS(f"\n{len(DILEMMAS)} ta vaziyat muvaffaqiyatli kiritildi."))
