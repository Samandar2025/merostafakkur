from django.core.management.base import BaseCommand
from rest_framework.test import APIRequestFactory, force_authenticate

from accounts.models import User
from dilemmas.models import MoralDilemma
from dilemmas.views import (
    ChooseOptionView,
    StartOrResumeMoralChoiceView,
    SubmitJustificationView,
    SubmitOutcomeView,
)


class Command(BaseCommand):
    help = "2-modul oqimini sinaydi: tanlov -> asoslash -> oqibat, va tartib buzilishini rad etish"

    def handle(self, *args, **options):
        student, _ = User.objects.get_or_create(
            username="test_student_m2", defaults={"role": User.Role.STUDENT}
        )
        dilemma = MoralDilemma.objects.get(title="Topilgan ruchka")
        factory = APIRequestFactory()

        def call(view_cls, method_name, path, data, user=None, **kwargs):
            user = user or student
            req = getattr(factory, method_name)(path, data, format="json")
            force_authenticate(req, user=user)
            return view_cls.as_view()(req, **kwargs)

        self.stdout.write("1) Submission boshlanmoqda...")
        resp = call(StartOrResumeMoralChoiceView, "post", "/start/", {}, dilemma_id=dilemma.id)
        self.stdout.write(f"   status={resp.status_code} status_field={resp.data['status']}")
        submission_id = resp.data["id"]

        self.stdout.write("\n2) Asoslashni TANLOVDAN OLDIN yuborishga urinish (rad etilishi kerak)...")
        resp = call(SubmitJustificationView, "post", "/justify/",
                     {"justification_text": "Tartibni buzish"}, submission_id=submission_id)
        self.stdout.write(f"   status={resp.status_code} data={resp.data}")
        assert resp.status_code == 400, "Tanlovsiz asoslash rad etilishi kerak edi!"

        self.stdout.write("\n3) Variant tanlanmoqda (C — to'g'ri xulq)...")
        option_c = dilemma.options.get(display_order=3)
        resp = call(ChooseOptionView, "post", "/choose/", {"option_id": option_c.id},
                     submission_id=submission_id)
        self.stdout.write(f"   status={resp.status_code} tanlangan={resp.data['selected_option']['option_text'][:40]}...")

        self.stdout.write("\n4) Tanlovni O'ZGARTIRISHGA urinish (rad etilishi kerak)...")
        option_a = dilemma.options.get(display_order=1)
        resp = call(ChooseOptionView, "post", "/choose/", {"option_id": option_a.id},
                     submission_id=submission_id)
        self.stdout.write(f"   status={resp.status_code} data={resp.data}")
        assert resp.status_code == 400, "Tanlovni o'zgartirish rad etilishi kerak edi!"

        self.stdout.write("\n5) Oqibatni ASOSLASHDAN OLDIN yuborishga urinish (rad etilishi kerak)...")
        resp = call(SubmitOutcomeView, "post", "/outcome/",
                     {"outcome_prediction_text": "Tartibni buzish"}, submission_id=submission_id)
        self.stdout.write(f"   status={resp.status_code} data={resp.data}")
        assert resp.status_code == 400, "Asoslashsiz oqibat rad etilishi kerak edi!"

        self.stdout.write("\n6) Asoslash to'g'ri tartibda yuborilmoqda...")
        resp = call(SubmitJustificationView, "post", "/justify/",
                     {"justification_text": "Chunki egasini topish to'g'ri ish."},
                     submission_id=submission_id)
        self.stdout.write(f"   status={resp.status_code} yangi_status={resp.data['status']}")

        self.stdout.write("\n7) Oqibat bashorati yuborilmoqda...")
        resp = call(SubmitOutcomeView, "post", "/outcome/",
                     {"outcome_prediction_text": "Ruchka egasi topilib, hammaga yaxshi bo'ladi."},
                     submission_id=submission_id)
        self.stdout.write(f"   status={resp.status_code} yakuniy_status={resp.data['status']}")
        assert resp.data["status"] == "completed"

        self.stdout.write(self.style.SUCCESS("\n2-modul oqimi to'liq va to'g'ri ishlayapti ✅"))
