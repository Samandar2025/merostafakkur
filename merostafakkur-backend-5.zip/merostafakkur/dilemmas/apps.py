from django.apps import AppConfig


class DilemmasConfig(AppConfig):
    name = 'dilemmas'
