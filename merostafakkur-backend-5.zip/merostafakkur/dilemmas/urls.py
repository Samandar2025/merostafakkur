from django.urls import path

from . import views

app_name = "dilemmas"

urlpatterns = [
    path(
        "dilemmas/<int:dilemma_id>/start/",
        views.StartOrResumeMoralChoiceView.as_view(),
        name="start-or-resume",
    ),
    path(
        "submissions/<int:submission_id>/choose/",
        views.ChooseOptionView.as_view(),
        name="choose-option",
    ),
    path(
        "submissions/<int:submission_id>/justify/",
        views.SubmitJustificationView.as_view(),
        name="submit-justification",
    ),
    path(
        "submissions/<int:submission_id>/outcome/",
        views.SubmitOutcomeView.as_view(),
        name="submit-outcome",
    ),
]
