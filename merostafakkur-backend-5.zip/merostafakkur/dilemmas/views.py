from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import get_object_or_404
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import DilemmaOption, MoralChoiceSubmission, MoralDilemma
from .serializers import (
    ChooseOptionSerializer,
    JustificationSerializer,
    MoralChoiceSubmissionSerializer,
    OutcomeSerializer,
)


class IsStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_student())


class StartOrResumeMoralChoiceView(APIView):
    permission_classes = [IsStudent]

    def post(self, request, dilemma_id):
        dilemma = get_object_or_404(MoralDilemma, id=dilemma_id, is_active=True)
        submission, _ = MoralChoiceSubmission.objects.get_or_create(
            student=request.user, dilemma=dilemma, assigned_by=None,
        )
        return Response(MoralChoiceSubmissionSerializer(submission).data)


class ChooseOptionView(APIView):
    """Tanlov qilish — bir marta, keyin o'zgartirib bo'lmaydi."""

    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(
            MoralChoiceSubmission, id=submission_id, student=request.user,
        )
        serializer = ChooseOptionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        option = get_object_or_404(DilemmaOption, id=serializer.validated_data["option_id"])
        try:
            submission.choose_option(option)
        except DjangoValidationError as e:
            return Response({"detail": e.messages}, status=status.HTTP_400_BAD_REQUEST)
        return Response(MoralChoiceSubmissionSerializer(submission).data)


class SubmitJustificationView(APIView):
    """Asoslash — faqat tanlovdan keyin, bir marta."""

    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(
            MoralChoiceSubmission, id=submission_id, student=request.user,
        )
        serializer = JustificationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            submission.submit_justification(serializer.validated_data["justification_text"])
        except DjangoValidationError as e:
            return Response({"detail": e.messages}, status=status.HTTP_400_BAD_REQUEST)
        return Response(MoralChoiceSubmissionSerializer(submission).data)


class SubmitOutcomeView(APIView):
    """Oqibat bashorati — faqat asoslashdan keyin, bir marta. Bu bilan submission yakunlanadi."""

    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(
            MoralChoiceSubmission, id=submission_id, student=request.user,
        )
        serializer = OutcomeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            submission.submit_outcome(serializer.validated_data["outcome_prediction_text"])
        except DjangoValidationError as e:
            return Response({"detail": e.messages}, status=status.HTTP_400_BAD_REQUEST)
        return Response(MoralChoiceSubmissionSerializer(submission).data)
