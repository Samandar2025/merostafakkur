from django.contrib import admin

from .models import DilemmaOption, MoralChoiceSubmission, MoralDilemma


class DilemmaOptionInline(admin.TabularInline):
    model = DilemmaOption
    extra = 1
    ordering = ["display_order"]


@admin.register(MoralDilemma)
class MoralDilemmaAdmin(admin.ModelAdmin):
    list_display = ["title", "value_focus", "age_group", "is_active"]
    search_fields = ["title", "scenario_text"]
    inlines = [DilemmaOptionInline]


@admin.register(MoralChoiceSubmission)
class MoralChoiceSubmissionAdmin(admin.ModelAdmin):
    """
    O'qituvchi bu yerda tanlov + asoslash + oqibat bashoratini birgalikda,
    bitta 'hikoya' ko'rinishida ko'radi.
    """

    list_display = ["student", "dilemma", "status", "selected_option", "updated_at"]
    list_filter = ["status", "dilemma"]
    search_fields = ["student__username"]
    readonly_fields = [
        "selected_option", "option_chosen_at",
        "justification_text", "justification_at",
        "outcome_prediction_text", "outcome_predicted_at",
        "created_at", "updated_at",
    ]
