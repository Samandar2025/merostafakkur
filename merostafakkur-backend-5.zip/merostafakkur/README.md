# MerosTafakkur — Backend (1-modul: "Meros izidan")

## VS Code'da ochish

1. VS Code'ni oching → **File → Open Folder** → `merostafakkur` papkasini tanlang
2. Pastdagi taklif chiqsa — **Python** kengaytmasini o'rnatishni tavsiya qiladi, o'rnating (`Install` tugmasi)
3. Terminal oching: **Terminal → New Terminal** (yoki `` Ctrl+` ``)
4. Quyidagi "Ishga tushirish" bo'limidagi buyruqlarni shu terminalda bajaring
5. Virtual muhitni yaratgach, VS Code pastki-o'ng burchakda "Select Interpreter" taklifini ko'rsatishi mumkin — `venv` papkasidagi Python'ni tanlang (yoki `Ctrl+Shift+P` → "Python: Select Interpreter" → `./venv` ichidagisini tanlang)
6. Serverni ishga tushirish uchun ikki yo'l bor:
   - Terminal orqali: `python manage.py runserver`
   - Yoki VS Code'ning **Run and Debug** (chap panel, ▷ belgisi) bo'limidan "Django: runserver" ni tanlab F5 bosing — bu debug rejimida ishga tushiradi (breakpoint qo'yish imkoniyati bilan)

## Ishga tushirish

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser      # admin panel uchun
python manage.py seed_demo_material   # "Ikki qo'shni oila" namunasini bazaga kiritadi

python manage.py runserver
```

Admin panel: http://127.0.0.1:8000/admin/

## Loyiha strukturasi

- `accounts/` — foydalanuvchilar (o'quvchi/o'qituvchi), maktab, sinf modellari
- `heritage/` — 1-modul "Meros izidan": meros materiallari, savollar, o'quvchi javoblari

## 1-modul API endpoint'lari

| Method | URL | Vazifa |
|---|---|---|
| POST | `/api/heritage/materials/<id>/start/` | Materialni boshlash/davom ettirish |
| POST | `/api/heritage/submissions/<id>/video-progress/` | Video progressini yuborish (har ~5 soniyada) |
| POST | `/api/heritage/submissions/<id>/answer/` | Navbatdagi savolga javob yuborish |

**Muhim:** barcha ketma-ketlik va video-nazorat tekshiruvlari **backend darajasida** amalga oshiriladi
(`heritage/models.py` va `heritage/views.py`) — frontend buni chetlab o'tolmaydi.

## Production uchun PostgreSQL'ga o'tish

`.env` yoki muhit o'zgaruvchilarida:
```
DB_ENGINE=postgres
DB_NAME=merostafakkur
DB_USER=...
DB_PASSWORD=...
DB_HOST=...
DB_PORT=5432
```
Va `psycopg2-binary` paketini o'rnating: `pip install psycopg2-binary`

## Test qilish

```bash
python manage.py test_flow_demo
```
Bu buyruq 1-modulning to'liq oqimini (video progress, forward-seek bloklash,
ketma-ket savollar, xato holatlar) sinab, natijani konsolga chiqaradi.

## Companion (4-modul: AI hamroh)

Ikkita rejim:
1. **Hint (real vaqt yordami)** — `/api/companion/hint/`. Hech qachon javob taklif qilmaydi,
   faqat tushuntiradi. O'qituvchi tasdig'i shart emas.
2. **Yakuniy tahlil** — 1/2/3-modul yakunlanganda **avtomatik** (signal orqali) yaratiladi,
   lekin **hech qachon** bolaga to'g'ridan-to'g'ri chiqmaydi. O'qituvchi
   `/api/companion/summaries/pending/` da ko'radi, `/approve/` yoki `/reject/` qiladi.

**Production uchun MUHIM:** `ANTHROPIC_API_KEY` muhit o'zgaruvchisini albatta sozlang:
```bash
export ANTHROPIC_API_KEY=sk-ant-...
```
Buni sozlamasangiz, hint va tahlil funksiyalari xato qaytaradi (lekin tizim qulamaydi).

Test: `python manage.py test_companion_flow` — bu API kalitisiz ishlaydi (mock qilingan).

## Portal (o'quvchi kirish va bosh sahifa)

Bu **haqiqiy Django sahifalar** (server tomonidan render qilinadigan) — vizual demodan farqli,
to'g'ridan-to'g'ri bazaga ulangan.

- `/login/` — o'quvchi o'z ISMINI yozib kiradi (kod eslab yurish shart emas). Agar bir xil
  ismli bir nechta o'quvchi bo'lsa, ro'yxatdan tanlash so'raladi. **Diqqat:** bu past-xavfsizlikli
  usul — istalgan kishi boshqa o'quvchining ismini yozib, uning hisobiga kirishi mumkin. Bu
  ataylab shunday (foydalanuvchi so'roviga ko'ra) — maktab sinfida o'qituvchi nazorati ostida
  ishlatilishi ko'zda tutilgan.
- `/` — bosh sahifa: shu o'quvchiga (yoki uning sinfiga) biriktirilgan barcha topshiriqlar,
  har birining haqiqiy holati (Bajarildi/Boshlanmagan/...) bilan

**Topshiriq biriktirish (Assignment)** hozircha faqat Django admin orqali:
Admin panel → Assignments → Add. `assigned_to_student` YOKI `assigned_to_class` dan
faqat bittasini tanlang, content type (heritage material / moral dilemma / kindness task)
va object id ni ko'rsating.

**MUHIM (production uchun):** `ALLOWED_HOSTS` da hozircha faqat test/local qiymatlar bor
(`config/settings.py`) — haqiqiy domenni albatta qo'shing.

Test: `python manage.py test_portal_flow` — kirish, bosh sahifa, individual va sinf orqali
biriktirish, izolyatsiya (boshqa o'quvchi ishini ko'rmasligi) hammasi tekshiriladi.

## Keyingi bosqichlar (hali yozilmagan)

- 2-modul: "Men qanday yo'l tutaman?" (moral_dilemmas)
- 3-modul: "Ezgu ishlarim" (kindness_tasks)
- 4-modul: "O'zimga nazar" + AI hamroh (reflection + AI summary moderation)
- O'qituvchi uchun to'liq frontend (topshiriq biriktirish sahifasi, natijalarni ko'rish, AI tahlilini tasdiqlash)
- O'quvchi uchun har bir modulning haqiqiy backend'ga ulangan interfeysi (hozircha faqat vizual demo va API bor)
- Topshiriq biriktirish (Assignment) modeli — hozircha `assigned_by` bo'sh qoldirilgan
- Autentifikatsiya: o'quvchi uchun kod/QR orqali kirish (hozircha standart Django auth)
