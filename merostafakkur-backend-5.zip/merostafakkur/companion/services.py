"""
Bu modul Anthropic API bilan real muloqotni amalga oshiradi.
Testlarda `call_claude` funksiyasi monkeypatch qilinadi — haqiqiy tarmoq
so'rovi yuborilmaydi, shuning uchun test muhitida ANTHROPIC_API_KEY shart emas.
"""

import json
import os

import requests

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
MODEL = "claude-sonnet-4-6"


class CompanionSafetyError(Exception):
    """AI javobi xavfsizlik/kontent filtridan o'tmadi."""


def call_claude(system_prompt: str, user_message: str, max_tokens: int = 400) -> str:
    """
    Anthropic API'ga so'rov yuboradi. Production'da ANTHROPIC_API_KEY muhit
    o'zgaruvchisi orqali beriladi.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError(
            "ANTHROPIC_API_KEY sozlanmagan. Production serverida muhit o'zgaruvchisi "
            "sifatida qo'shing: export ANTHROPIC_API_KEY=..."
        )
    response = requests.post(
        ANTHROPIC_API_URL,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        data=json.dumps({
            "model": MODEL,
            "max_tokens": max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_message}],
        }),
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()
    return "".join(block.get("text", "") for block in data.get("content", []) if block.get("type") == "text")


def passes_content_moderation(text: str) -> bool:
    """
    Oddiy xavfsizlik filtri. Production'da bu alohida moderatsiya
    modeli/API'siga almashtirilishi tavsiya etiladi.
    """
    if not text or not text.strip():
        return False
    blocked_markers = ["<script", "http://", "https://"]  # havola/kod yubormasligi kerak
    lowered = text.lower()
    return not any(marker in lowered for marker in blocked_markers)


# ---- 1. Real vaqt yordami (hint) ----

HINT_SYSTEM_PROMPT_TEMPLATE = """Sen MerosTafakkur platformasidagi bolalar uchun yordamchisan.
Sening vazifang — FAQAT quyida berilgan matn asosida bolaga tushunishga yordam berish.

QATTIQ QOIDALAR:
1. Hech qachon savolga TO'G'RI JAVOBNI aytib berma yoki taklif qilma.
2. Faqat: (a) so'zlarni sodda tilda tushuntirishing, (b) savolni boshqacha so'z bilan qayta ayting,
   (c) bolani mustaqil fikrlashga undang mumkin.
3. Faqat quyida berilgan mavzu doirasida gaplash. Boshqa mavzu so'ralsa
   ("menga she'r yoz", "matematika masalasi yech" va h.k.), muloyimlik bilan
   rad et va mavzuga qaytar.
4. Har doim iliq, qo'llab-quvvatlovchi ohangda, bolalarga mos oddiy tilda yoz.
5. Javobing 2-3 gapdan oshmasin.

MAVZU MATNI:
{context_text}
"""


def get_hint_response(context_text: str, student_query: str) -> str:
    system_prompt = HINT_SYSTEM_PROMPT_TEMPLATE.format(context_text=context_text)
    user_message = student_query.strip() if student_query.strip() else "Menga tushunishga yordam bering."
    text = call_claude(system_prompt, user_message, max_tokens=200)
    if not passes_content_moderation(text):
        raise CompanionSafetyError("AI javobi xavfsizlik filtridan o'tmadi.")
    return text


# ---- 2. Yakuniy shaxsiy tahlil (4-modul) ----

REFLECTION_SYSTEM_PROMPT = """Sen MerosTafakkur platformasidagi bolalar uchun samimiy hamrohsan.
Quyida bitta o'quvchining 1, 2, 3-modullardagi javoblari (strukturaviy JSON shaklida) berilgan.

VAZIFANG: shu ma'lumotlar asosida bolaga qaratilgan, ILIQ va HUKM QILMAYDIGAN qisqa
tahlil yoz (4-6 gap). Bola nimalarni yaxshi bajarganini KONKRET misollar bilan
(umumiy "zo'rsan!" emas) ko'rsat.

QATTIQ QOIDALAR:
1. Faqat berilgan ma'lumotlar asosida gapir — hech narsa o'ylab topma.
2. Hech qachon salbiy baho yoki tanqid berma.
3. Bolani ism bilan emas, "Siz" deb murojaat qil.
4. Oxirida bitta yengil, ilhomlantiruvchi savol yoki taklif bilan yakunla.
5. Bolalar tiliga mos, oddiy va iliq bo'lsin.

O'QUVCHI MA'LUMOTLARI (JSON):
{student_data}
"""


def generate_reflection_text(student_data: dict) -> str:
    system_prompt = REFLECTION_SYSTEM_PROMPT.format(
        student_data=json.dumps(student_data, ensure_ascii=False, indent=2),
    )
    text = call_claude(system_prompt, "Tahlil yozing.", max_tokens=500)
    if not passes_content_moderation(text):
        raise CompanionSafetyError("AI javobi xavfsizlik filtridan o'tmadi.")
    return text
