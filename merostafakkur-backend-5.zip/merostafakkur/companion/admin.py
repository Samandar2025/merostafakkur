from django.contrib import admin

from .models import CompanionHint, StudentAISummary


@admin.register(CompanionHint)
class CompanionHintAdmin(admin.ModelAdmin):
    list_display = ["student", "context_type", "context_object_id", "created_at"]
    list_filter = ["context_type"]
    search_fields = ["student__username", "student_query", "ai_response"]
    readonly_fields = ["student", "context_type", "context_object_id", "student_query", "ai_response", "created_at"]


@admin.register(StudentAISummary)
class StudentAISummaryAdmin(admin.ModelAdmin):
    """
    O'qituvchi shu yerda AI tahlilini ko'rib, tasdiqlaydi yoki tahrir qiladi.
    Diqqat: bola faqat 'shown_to_student_at' to'lgandan keyingina ko'radi.
    """

    list_display = ["student", "status", "trigger_source", "generated_at", "shown_to_student_at"]
    list_filter = ["status", "trigger_source"]
    search_fields = ["student__username", "ai_generated_text"]
    readonly_fields = ["student", "trigger_source", "source_data_snapshot", "ai_generated_text", "generated_at"]
