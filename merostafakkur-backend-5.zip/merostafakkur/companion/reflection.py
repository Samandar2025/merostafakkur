"""
1, 2, 3-moduldagi YAKUNLANGAN submission'larni yig'ib, AI tahlili uchun
strukturaviy ma'lumot tayyorlaydi va StudentAISummary yozuvini yaratadi.

Bu funksiya har safar biror submission "completed" holatiga o'tganda
signal orqali avtomatik chaqiriladi (companion/signals.py ga qarang).
"""

import logging

from . import services
from .models import StudentAISummary

logger = logging.getLogger(__name__)


def _collect_student_data(student):
    from dilemmas.models import MoralChoiceSubmission
    from heritage.models import ValueAnalysisSubmission
    from kindness.models import KindnessSubmission

    data = {"heritage": [], "dilemmas": [], "kindness_tasks": []}

    for sub in ValueAnalysisSubmission.objects.filter(student=student, status="completed"):
        data["heritage"].append({
            "material_title": sub.material.title,
            "answers": [
                {
                    "question": a.question.question_text,
                    "answer": a.answer_text or ", ".join(a.selected_value_tags),
                }
                for a in sub.answers.all()
            ],
        })

    for sub in MoralChoiceSubmission.objects.filter(student=student, status="completed"):
        data["dilemmas"].append({
            "dilemma_title": sub.dilemma.title,
            "chosen_option": sub.selected_option.option_text if sub.selected_option else None,
            "justification": sub.justification_text,
            "outcome_prediction": sub.outcome_prediction_text,
        })

    for sub in KindnessSubmission.objects.filter(student=student, status="completed"):
        data["kindness_tasks"].append({
            "task_title": sub.task.title,
            "value": sub.task.value.name,
            "what_i_did": sub.what_i_did_text,
            "with_whom": sub.with_whom_text,
            "result": sub.result_text,
        })

    return data


def generate_summary_for_student(student, trigger_source):
    """
    Diqqat: bu funksiya AI matnini yaratadi, lekin uni HECH QACHON to'g'ridan-to'g'ri
    bolaga ko'rsatmaydi — status har doim 'pending_review' bilan boshlanadi.
    """
    student_data = _collect_student_data(student)

    # Hech narsa yakunlanmagan bo'lsa, tahlil yaratishning ma'nosi yo'q.
    if not any(student_data.values()):
        return None

    try:
        ai_text = services.generate_reflection_text(student_data)
    except services.CompanionSafetyError:
        logger.warning("AI tahlili xavfsizlik filtridan o'tmadi: student_id=%s", student.id)
        return None
    except RuntimeError as e:
        logger.warning("AI tahlili yaratilmadi (API sozlanmagan): %s", e)
        return None

    return StudentAISummary.objects.create(
        student=student,
        trigger_source=trigger_source,
        source_data_snapshot=student_data,
        ai_generated_text=ai_text,
        status=StudentAISummary.Status.PENDING_REVIEW,
    )
