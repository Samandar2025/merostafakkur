from django.apps import AppConfig


class CompanionConfig(AppConfig):
    name = 'companion'

    def ready(self):
        from . import signals  # noqa: F401
