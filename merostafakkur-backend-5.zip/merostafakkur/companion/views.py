from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import permissions, serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView

from dilemmas.models import MoralDilemma
from heritage.models import HeritageMaterial
from kindness.models import KindnessTask

from . import services
from .models import CompanionHint, StudentAISummary


class IsStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_student())


class IsTeacher(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_teacher())


class HintRequestSerializer(serializers.Serializer):
    context_type = serializers.ChoiceField(choices=CompanionHint.ContextType.choices)
    context_object_id = serializers.IntegerField()
    student_query = serializers.CharField(required=False, allow_blank=True, default="")


CONTEXT_LOOKUP = {
    CompanionHint.ContextType.HERITAGE: HeritageMaterial,
    CompanionHint.ContextType.DILEMMA: MoralDilemma,
    CompanionHint.ContextType.KINDNESS: KindnessTask,
}


def _build_context_text(context_type, obj):
    """
    Diqqat: bu yerda faqat o'sha material/vaziyat/topshiriqning matni beriladi —
    boshqa hech qanday tashqi yoki boshqa o'quvchilarga oid ma'lumot emas.
    """
    if context_type == CompanionHint.ContextType.HERITAGE:
        return f"Rivoyat sarlavhasi: {obj.title}\nMatni: {obj.body_text}"
    if context_type == CompanionHint.ContextType.DILEMMA:
        options = "\n".join(f"- {o.option_text}" for o in obj.options.all())
        return f"Vaziyat: {obj.scenario_text}\nVariantlar:\n{options}"
    if context_type == CompanionHint.ContextType.KINDNESS:
        return f"Topshiriq: {obj.title}\nYo'riqnoma: {obj.instruction_text}"
    return ""


class HintRequestView(APIView):
    """
    Real vaqt yordami. Har doim ishlaydi, o'qituvchi tasdig'i shart emas —
    chunki bolaning shaxsiy fikriga aralashmaydi, faqat mavzuni tushuntiradi.
    """

    permission_classes = [IsStudent]

    def post(self, request):
        s = HintRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        model = CONTEXT_LOOKUP[data["context_type"]]
        obj = get_object_or_404(model, id=data["context_object_id"])
        context_text = _build_context_text(data["context_type"], obj)

        try:
            ai_text = services.get_hint_response(context_text, data["student_query"])
        except services.CompanionSafetyError:
            return Response(
                {"detail": "Kechirasiz, hozir yordam bera olmayman. O'qituvchingizdan so'rang."},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )
        except RuntimeError as e:
            return Response({"detail": str(e)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

        CompanionHint.objects.create(
            student=request.user,
            context_type=data["context_type"],
            context_object_id=obj.id,
            student_query=data["student_query"],
            ai_response=ai_text,
        )
        return Response({"response": ai_text})


class PendingSummariesView(APIView):
    """O'qituvchi: ko'rib chiqilishi kerak bo'lgan AI tahlillar ro'yxati."""

    permission_classes = [IsTeacher]

    def get(self, request):
        summaries = StudentAISummary.objects.filter(status=StudentAISummary.Status.PENDING_REVIEW)
        return Response([
            {
                "id": s.id,
                "student": s.student.get_full_name() or s.student.username,
                "ai_generated_text": s.ai_generated_text,
                "trigger_source": s.trigger_source,
                "generated_at": s.generated_at,
            }
            for s in summaries
        ])


class ApproveSummarySerializer(serializers.Serializer):
    edited_text = serializers.CharField(required=False, allow_blank=True, default="")


class ApproveSummaryView(APIView):
    """O'qituvchi tasdiqlaydi — ixtiyoriy ravishda tahrir qilib. Shundan keyingina bolaga ko'rinadi."""

    permission_classes = [IsTeacher]

    def post(self, request, summary_id):
        summary = get_object_or_404(StudentAISummary, id=summary_id)
        s = ApproveSummarySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        edited_text = s.validated_data["edited_text"].strip()

        summary.final_text = edited_text if edited_text else summary.ai_generated_text
        summary.status = (
            StudentAISummary.Status.EDITED if edited_text else StudentAISummary.Status.APPROVED
        )
        summary.teacher_reviewed_by = request.user
        summary.teacher_reviewed_at = timezone.now()
        summary.shown_to_student_at = timezone.now()
        summary.save()
        return Response({"status": summary.status, "final_text": summary.final_text})


class RejectSummaryView(APIView):
    permission_classes = [IsTeacher]

    def post(self, request, summary_id):
        summary = get_object_or_404(StudentAISummary, id=summary_id)
        summary.status = StudentAISummary.Status.REJECTED
        summary.teacher_reviewed_by = request.user
        summary.teacher_reviewed_at = timezone.now()
        summary.save()
        return Response({"status": summary.status})
