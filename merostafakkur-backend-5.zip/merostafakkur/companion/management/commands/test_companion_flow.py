"""
Bu test ANTHROPIC_API_KEY talab qilmaydi — services.call_claude funksiyasi
monkeypatch qilinadi, shuning uchun haqiqiy tarmoq so'rovi yuborilmaydi.
"""

from unittest.mock import patch

from django.core.management.base import BaseCommand
from rest_framework.test import APIRequestFactory, force_authenticate

from accounts.models import User
from companion import services
from companion.models import StudentAISummary
from companion.views import ApproveSummaryView, HintRequestView, PendingSummariesView
from dilemmas.models import MoralDilemma
from dilemmas.views import ChooseOptionView, StartOrResumeMoralChoiceView, SubmitJustificationView, SubmitOutcomeView
from heritage.models import HeritageMaterial


def fake_hint_response(context_text, student_query):
    return "Bu so'z 'birgalikda ish qilish' degan ma'noni anglatadi. O'zingiz qanday o'ylaysiz?"


def fake_reflection_text(student_data):
    n_dilemmas = len(student_data.get("dilemmas", []))
    return (
        f"Siz {n_dilemmas} ta vaziyatda o'z qaroringizni asosladingiz — bu juda yaxshi! "
        "Xususan, qo'shningizga yordam berish haqida chuqur o'yladingiz. "
        "Keyingi safar yana qaysi ezgu ishni sinab ko'rmoqchisiz?"
    )


class Command(BaseCommand):
    help = "Companion (hint + 4-modul AI tahlili) oqimini mock API bilan sinaydi"

    def handle(self, *args, **options):
        student, _ = User.objects.get_or_create(
            username="test_student_companion", defaults={"role": User.Role.STUDENT}
        )
        teacher, _ = User.objects.get_or_create(
            username="test_teacher_companion", defaults={"role": User.Role.TEACHER}
        )
        factory = APIRequestFactory()

        def call(view_cls, method_name, path, data, user, **kwargs):
            req = getattr(factory, method_name)(path, data, format="json")
            force_authenticate(req, user=user)
            return view_cls.as_view()(req, **kwargs)

        # ---- 1) Real vaqt yordami (hint) ----
        self.stdout.write("1) Hint so'rovi yuborilmoqda (1-modul materiali uchun)...")
        material = HeritageMaterial.objects.first()
        with patch.object(services, "call_claude", return_value=fake_hint_response(None, None)):
            resp = call(HintRequestView, "post", "/hint/", {
                "context_type": "heritage",
                "context_object_id": material.id,
                "student_query": "qo'shnichilik nima degani?",
            }, student)
        self.stdout.write(f"   status={resp.status_code} javob={resp.data.get('response', resp.data)[:60]}...")
        assert resp.status_code == 200

        # ---- 2) Hint javobida "javob" so'zi yo'qligini tekshirish (mazmuniy tekshiruv emas, log borligini) ----
        from companion.models import CompanionHint
        assert CompanionHint.objects.filter(student=student).count() == 1
        self.stdout.write("   ✓ Hint jurnalga yozildi")

        # ---- 3) 2-modulni to'liq bajarib, signal orqali AI tahlili avtomatik yaratilishini tekshirish ----
        self.stdout.write("\n2) 2-modulni yakunlab, AI tahlili avtomatik ishga tushishini tekshiramiz...")
        dilemma = MoralDilemma.objects.first()

        with patch.object(services, "call_claude", return_value=fake_reflection_text({"dilemmas": [1]})):
            resp = call(StartOrResumeMoralChoiceView, "post", "/start/", {}, student, dilemma_id=dilemma.id)
            sid = resp.data["id"]
            option = dilemma.options.first()
            call(ChooseOptionView, "post", "/choose/", {"option_id": option.id}, student, submission_id=sid)
            call(SubmitJustificationView, "post", "/justify/", {"justification_text": "Chunki to'g'ri."}, student, submission_id=sid)
            resp = call(SubmitOutcomeView, "post", "/outcome/", {"outcome_prediction_text": "Yaxshi bo'ladi."}, student, submission_id=sid)
        self.stdout.write(f"   submission status={resp.data['status']}")

        summary = StudentAISummary.objects.filter(student=student).order_by("-generated_at").first()
        assert summary is not None, "Signal orqali AI tahlili yaratilmadi!"
        assert summary.status == "pending_review", "Yangi tahlil pending_review holatida bo'lishi kerak edi!"
        self.stdout.write(f"   ✓ AI tahlili avtomatik yaratildi (status={summary.status})")
        self.stdout.write(f"   Matn: {summary.ai_generated_text[:70]}...")

        # ---- 4) Tahlil hali bolaga ko'rinmasligini tekshirish ----
        assert summary.shown_to_student_at is None
        self.stdout.write("   ✓ Tahlil hali bolaga ko'rinmaydi (shown_to_student_at bo'sh)")

        # ---- 5) O'qituvchi ro'yxatda ko'radi ----
        self.stdout.write("\n3) O'qituvchi kutilayotgan tahlillarni ko'radi...")
        resp = call(PendingSummariesView, "get", "/pending/", {}, teacher)
        assert resp.status_code == 200 and len(resp.data) >= 1
        self.stdout.write(f"   ✓ {len(resp.data)} ta tahlil kutilmoqda")

        # ---- 6) O'qituvchi tasdiqlaydi (tahrirsiz) ----
        self.stdout.write("\n4) O'qituvchi tasdiqlaydi...")
        resp = call(ApproveSummaryView, "post", f"/approve/", {}, teacher, summary_id=summary.id)
        self.stdout.write(f"   status={resp.status_code} yakuniy_holat={resp.data['status']}")
        summary.refresh_from_db()
        assert summary.status == "approved"
        assert summary.shown_to_student_at is not None
        self.stdout.write("   ✓ Endi bolaga ko'rinadi (shown_to_student_at to'ldi)")

        self.stdout.write(self.style.SUCCESS("\nCompanion (hint + 4-modul) oqimi to'liq va to'g'ri ishlayapti ✅"))
