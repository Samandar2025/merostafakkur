from django.urls import path

from . import views

app_name = "companion"

urlpatterns = [
    path("hint/", views.HintRequestView.as_view(), name="hint"),
    path("summaries/pending/", views.PendingSummariesView.as_view(), name="pending-summaries"),
    path("summaries/<int:summary_id>/approve/", views.ApproveSummaryView.as_view(), name="approve-summary"),
    path("summaries/<int:summary_id>/reject/", views.RejectSummaryView.as_view(), name="reject-summary"),
]
