from django.db.models.signals import post_save
from django.dispatch import receiver

from dilemmas.models import MoralChoiceSubmission
from heritage.models import ValueAnalysisSubmission
from kindness.models import KindnessSubmission

from .models import StudentAISummary
from .reflection import generate_summary_for_student


@receiver(post_save, sender=ValueAnalysisSubmission)
def on_heritage_completed(sender, instance, **kwargs):
    if instance.status == "completed":
        generate_summary_for_student(instance.student, StudentAISummary.TriggerSource.HERITAGE)


@receiver(post_save, sender=MoralChoiceSubmission)
def on_dilemma_completed(sender, instance, **kwargs):
    if instance.status == "completed":
        generate_summary_for_student(instance.student, StudentAISummary.TriggerSource.DILEMMA)


@receiver(post_save, sender=KindnessSubmission)
def on_kindness_completed(sender, instance, **kwargs):
    if instance.status == "completed":
        generate_summary_for_student(instance.student, StudentAISummary.TriggerSource.KINDNESS)
