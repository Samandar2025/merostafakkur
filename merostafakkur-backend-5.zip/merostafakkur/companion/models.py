from django.conf import settings
from django.db import models


class CompanionHint(models.Model):
    """
    Real vaqt yordami jurnali. Har bir yordam so'rovi qayd etiladi —
    ilmiy tahlil uchun ("bolalar qaysi joyda ko'proq yordam so'raydi") ham,
    xavfsizlik monitoringi uchun ham foydali.
    """

    class ContextType(models.TextChoices):
        HERITAGE = "heritage", "Meros izidan (1-modul)"
        DILEMMA = "dilemma", "Men qanday yo'l tutaman? (2-modul)"
        KINDNESS = "kindness", "Ezgu ishlarim (3-modul)"

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="companion_hints",
    )
    context_type = models.CharField(max_length=20, choices=ContextType.choices)
    context_object_id = models.PositiveIntegerField(help_text="Material/vaziyat/topshiriq id'si")
    student_query = models.TextField(blank=True, help_text="Bola yozgan savol (ixtiyoriy)")
    ai_response = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student} — {self.get_context_type_display()} yordami ({self.created_at:%Y-%m-%d %H:%M})"


class StudentAISummary(models.Model):
    """
    4-modul: 1-3 moduldagi natijalar asosida AI yozgan shaxsiy, samimiy tahlil.
    Hech qachon to'g'ridan-to'g'ri bolaga chiqmaydi — avval o'qituvchi tasdiqlaydi.
    """

    class Status(models.TextChoices):
        PENDING_REVIEW = "pending_review", "Ko'rib chiqilishi kutilmoqda"
        APPROVED = "approved", "Tasdiqlangan"
        REJECTED = "rejected", "Rad etilgan"
        EDITED = "edited", "Tahrirlangan va tasdiqlangan"

    class TriggerSource(models.TextChoices):
        HERITAGE = "heritage", "1-modul yakunlanganda"
        DILEMMA = "dilemma", "2-modul yakunlanganda"
        KINDNESS = "kindness", "3-modul yakunlanganda"
        MANUAL = "manual", "Qo'lda so'ralgan"

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="ai_summaries",
    )
    trigger_source = models.CharField(max_length=20, choices=TriggerSource.choices)
    source_data_snapshot = models.JSONField(
        help_text="Tahlil qaysi submission'lar asosida yaratilgani — qayta tekshirish uchun",
    )
    ai_generated_text = models.TextField()
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING_REVIEW)

    teacher_reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="reviewed_ai_summaries",
    )
    teacher_reviewed_at = models.DateTimeField(null=True, blank=True)
    final_text = models.TextField(
        blank=True, help_text="O'qituvchi tahrir qilsa, yakuniy matn shu yerda",
    )
    shown_to_student_at = models.DateTimeField(null=True, blank=True)

    generated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-generated_at"]

    def __str__(self):
        return f"{self.student} — {self.get_status_display()} ({self.generated_at:%Y-%m-%d})"
