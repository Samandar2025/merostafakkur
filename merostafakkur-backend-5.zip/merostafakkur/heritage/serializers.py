from rest_framework import serializers

from .models import (
    HeritageMaterial,
    MaterialQuestion,
    ValueAnalysisAnswer,
    ValueAnalysisSubmission,
)


class MaterialQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = MaterialQuestion
        fields = ["id", "question_text", "question_type", "allow_multiple_values", "display_order"]


class HeritageMaterialSerializer(serializers.ModelSerializer):
    """
    Diqqat: savollar ro'yxati bu yerda ATAYLAB berilmaydi.
    O'quvchi ekraniga savollar faqat navbati kelganda, alohida endpoint orqali chiqadi —
    aks holda frontend hammasini oldindan bilib, ketma-ketlikni chetlab o'tishi mumkin.
    """

    class Meta:
        model = HeritageMaterial
        fields = ["id", "title", "type", "age_group", "body_text", "video_url", "value_tags"]


class ValueAnalysisSubmissionSerializer(serializers.ModelSerializer):
    material = HeritageMaterialSerializer(read_only=True)
    next_question = serializers.SerializerMethodField()

    class Meta:
        model = ValueAnalysisSubmission
        fields = [
            "id", "material", "status", "video_progress_seconds",
            "video_completed_at", "next_question",
        ]
        read_only_fields = fields

    def get_next_question(self, obj):
        if not obj.can_answer_questions():
            return None
        q = obj.next_unanswered_question()
        return MaterialQuestionSerializer(q).data if q else None


class VideoProgressSerializer(serializers.Serializer):
    """Video pleyer taxminan har 5 soniyada shu endpoint'ga progress yuboradi."""

    progress_seconds = serializers.FloatField(min_value=0)


class AnswerSubmitSerializer(serializers.Serializer):
    question_id = serializers.IntegerField()
    answer_text = serializers.CharField(required=False, allow_blank=True, default="")
    selected_value_tags = serializers.ListField(
        child=serializers.CharField(), required=False, default=list,
    )

    def validate(self, attrs):
        try:
            question = MaterialQuestion.objects.get(id=attrs["question_id"])
        except MaterialQuestion.DoesNotExist:
            raise serializers.ValidationError("Savol topilmadi.")
        if question.question_type == MaterialQuestion.QuestionType.VALUE_SELECT:
            if not attrs.get("selected_value_tags"):
                raise serializers.ValidationError("Kamida bitta qadriyat tanlanishi shart.")
            if not question.allow_multiple_values and len(attrs["selected_value_tags"]) > 1:
                raise serializers.ValidationError("Bu savolda faqat bitta qadriyat tanlash mumkin.")
        else:
            if not attrs.get("answer_text"):
                raise serializers.ValidationError("Javob matni bo'sh bo'lishi mumkin emas.")
        attrs["question"] = question
        return attrs
