"""
Bu real 'test' emas (pytest emas), balki API oqimini ko'z bilan ko'rish uchun
qo'lda tekshirish skripti. Loyihaga rest_framework.authtoken kerak emas —
to'g'ridan-to'g'ri Django ORM va view funksiyalarini chaqiramiz.
"""
from django.core.management.base import BaseCommand
from rest_framework.test import APIRequestFactory, force_authenticate

from accounts.models import User
from heritage.models import HeritageMaterial
from heritage.views import StartOrResumeSubmissionView, SubmitAnswerView, VideoProgressView


class Command(BaseCommand):
    help = "1-modul oqimini uchtan-uchgacha sinaydi: video progress, forward-seek, ketma-ket savollar"

    def handle(self, *args, **options):
        student, _ = User.objects.get_or_create(
            username="test_student", defaults={"role": User.Role.STUDENT}
        )
        material = HeritageMaterial.objects.get(title="Ikki qo'shni oila")
        material.video_duration_seconds = 120
        material.save()

        factory = APIRequestFactory()

        def call(view_cls, method_name, path, data, user=None, **kwargs):
            user = user or student
            drf_request = getattr(factory, method_name)(path, data, format="json")
            force_authenticate(drf_request, user=user)
            view = view_cls.as_view()
            return view(drf_request, **kwargs)

        self.stdout.write("1) Submission boshlanmoqda...")
        resp = call(StartOrResumeSubmissionView, "post", "/start/", {}, material_id=material.id)
        self.stdout.write(f"   status={resp.status_code} data={resp.data}")
        submission_id = resp.data["id"]

        self.stdout.write("\n2) Forward-seek urinishi (0 -> 100 soniya, ruxsatsiz)...")
        resp = call(VideoProgressView, "post", "/progress/", {"progress_seconds": 100},
                     submission_id=submission_id)
        self.stdout.write(f"   status={resp.status_code} data={resp.data}")
        assert resp.status_code == 400, "Forward-seek bloklanishi kerak edi!"

        self.stdout.write("\n3) Normal progress — real pleyer kabi bosqichma-bosqich (har safar +10 soniya)...")
        for sec in range(10, 121, 10):
            resp = call(VideoProgressView, "post", "/progress/", {"progress_seconds": sec},
                         submission_id=submission_id)
            assert resp.status_code == 200, f"{sec}-soniyada kutilmagan xato: {resp.data}"
        self.stdout.write(f"   oxirgi status={resp.status_code} video_completed_at={resp.data['video_completed_at']}")
        assert resp.data["video_completed_at"] is not None, "Video tugagan deb belgilanishi kerak edi!"

        self.stdout.write("\n4) Savollarga video tugagach ketma-ket javob berish...")
        next_q = resp.data["next_question"]  # oxirgi progress javobidan olingan
        while next_q:
            self.stdout.write(f"   Savol #{next_q['display_order']}: {next_q['question_text'][:50]}...")
            answer_data = {"question_id": next_q["id"]}
            if next_q["question_type"] == "value_select":
                answer_data["selected_value_tags"] = ["qo'shnichilik"]
            else:
                answer_data["answer_text"] = "Test javobi."
            resp = call(SubmitAnswerView, "post", "/answer/", answer_data, submission_id=submission_id)
            self.stdout.write(f"      -> status={resp.status_code} yangi_status={resp.data.get('status')}")
            next_q = resp.data.get("next_question")

        self.stdout.write(self.style.SUCCESS("\nOqim to'liq yakunlandi. Status: completed ✅"))

        self.stdout.write("\n5) Yangi o'quvchi: video ko'rmasdan to'g'ridan-to'g'ri 2-savolga javob berishga urinadi...")
        student2, _ = User.objects.get_or_create(
            username="test_student_2", defaults={"role": User.Role.STUDENT}
        )
        resp = call(StartOrResumeSubmissionView, "post", "/start/", {}, user=student2, material_id=material.id)
        submission2_id = resp.data["id"]

        second_question = material.questions.order_by("display_order")[1]
        resp = call(
            SubmitAnswerView, "post", "/answer/",
            {"question_id": second_question.id, "answer_text": "Tartibni buzishga urinish"},
            user=student2, submission_id=submission2_id,
        )
        self.stdout.write(f"   status={resp.status_code} data={resp.data}")
        assert resp.status_code == 400, "Video tugamasdan/tartib buzilganda 400 qaytishi kerak edi!"
        self.stdout.write(self.style.SUCCESS("Ketma-ketlik va video-nazorat backendda to'g'ri ishlayapti ✅"))
