from django.core.management.base import BaseCommand

from heritage.models import HeritageMaterial, MaterialQuestion


class Command(BaseCommand):
    help = "Demo materiallarni ('Ikki qo'shni oila' va 'Bog'bon va uch farzand') bazaga kiritadi"

    def handle(self, *args, **options):
        self._seed_material_1()
        self._seed_material_2()
        self.stdout.write(self.style.SUCCESS("Ikkala demo material ham tayyor."))

    def _seed_material_1(self):
        material, _ = HeritageMaterial.objects.update_or_create(
            title="Ikki qo'shni oila",
            defaults=dict(
                type=HeritageMaterial.MaterialType.LEGEND,
                age_group=HeritageMaterial.AgeGroup.GRADE_1_2,
                body_text=(
                    "Bir mahallada yonma-yon yashaydigan ikki oila bo'lgan ekan. "
                    "Birinchi oilaning hovlisida katta o'rik daraxti bo'lib, har yili mo'l hosil "
                    "berar ekan. Daraxtning bir qancha shoxlari qo'shni hovliga ham egilib o'sibdi.\n\n"
                    "Bir kuni oila farzandi daraxtdagi o'riklarni terib, qo'shni tomondagi "
                    "shoxlarga ham qo'l uzatibdi. Otasi uni to'xtatib:\n"
                    "— U shoxlar bizning daraxtimizniki-ku, — debdi bola hayron bo'lib.\n"
                    "Otasi jilmayib:\n"
                    "— Daraxt bizniki, ammo uning soyasi ham, mevasi ham qo'shnimiz hovlisiga "
                    "kirib turibdi. Ne'matni baham ko'rsak, qo'shnichiligimiz yanada mustahkam "
                    "bo'ladi, — debdi.\n\n"
                    "Ular eng yaxshi o'riklardan bir savat qilib qo'shnisiga olib chiqishibdi. "
                    "Oradan kunlar o'tib, qo'shni oila ham o'z tomorqasidan yetishtirgan "
                    "sabzavotlardan ularga ulashibdi. Bolalar kattalarning bu munosabatini "
                    "kuzatib, yaxshi qo'shnichilik faqat yonma-yon yashash emasligini "
                    "tushunibdilar."
                ),
                video_url="",
                video_duration_seconds=30,
                value_tags=["qo'shnichilik", "saxovat", "hamjihatlik", "halollik"],
                source="Xalq og'zaki ijodi",
            ),
        )
        material.questions.all().delete()
        questions = [
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Ota nima uchun o'riklardan qo'shnisiga ham ulashishni istadi?", False),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Bolaning dastlabki fikri bilan otasining qarashi nimasi bilan farq qildi?", False),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Bir oilaning yaxshiligi ikkinchi oilaning munosabatiga qanday ta'sir ko'rsatdi?", False),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Qo'shnichilikni mustahkamlash uchun faqat moddiy narsa ulashish kerakmi?", False),
            (MaterialQuestion.QuestionType.VALUE_SELECT, "Rivoyatda qanday milliy-ma'naviy qadriyat aks etgan?", False),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Siz yaxshi qo'shnichilikni qanday xatti-harakatlar orqali namoyon etgan bo'lardingiz?", False),
        ]
        for i, (qtype, text, multi) in enumerate(questions, start=1):
            MaterialQuestion.objects.create(
                material=material, question_text=text, question_type=qtype,
                allow_multiple_values=multi, display_order=i,
            )
        self.stdout.write(self.style.SUCCESS(f"1-material tayyor: '{material.title}'"))

    def _seed_material_2(self):
        material, _ = HeritageMaterial.objects.update_or_create(
            title="Bog'bon va uch farzand",
            defaults=dict(
                type=HeritageMaterial.MaterialType.LEGEND,
                age_group=HeritageMaterial.AgeGroup.GRADE_1_2,
                body_text=(
                    "Qadimda bir bog'bonning katta bog'i bo'lgan ekan. Uning uch farzandi bor "
                    "edi. Farzandlari otasiga yordam berar, ammo har biri ishni yolg'iz "
                    "bajarishni yaxshi ko'rardi. Bir kuni kuchli shamol turib, bog'dagi yosh "
                    "nihollarning ayrimlarini egib yuboribdi.\n\n"
                    "Ertalab ota farzandlariga nihollarni tiklashni buyuribdi. Har biri "
                    "bog'ning bir tomonida yolg'iz ishlay boshlabdi. Biri niholni tutishga "
                    "qiynalsa, ikkinchisi tuproqni mustahkamlay olmabdi. Kun yarmiga yetgan "
                    "bo'lsa-da, ishning oz qismi bajarilibdi.\n\n"
                    "Shunda ota ularni yoniga chaqirib: \"Har biringizning kuchingiz bor, ammo "
                    "birlashmagan kuch ishni sekinlashtiradi\", debdi. Farzandlar vazifalarni "
                    "bo'lib olishibdi: biri niholni ushlab turibdi, ikkinchisi tuproq tortibdi, "
                    "uchinchisi esa suv quyibdi. Kechgacha barcha nihollar tiklanibdi.\n\n"
                    "Farzandlar o'sha kuni mehnatning faqat kuch bilan emas, hamjihatlik bilan "
                    "ham samarali bo'lishini anglabdilar."
                ),
                video_url="",
                video_duration_seconds=30,
                value_tags=["hamjihatlik", "mehnatsevarlik", "birdamlik", "sabr-toqat"],
                source="Xalq og'zaki ijodi",
            ),
        )
        material.questions.all().delete()
        questions = [
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Bog'da qanday muammo yuzaga keldi?", False),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Nima sababdan farzandlarning dastlabki mehnati samara bermadi?", False),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Otaning maslahati ularning faoliyatini qanday o'zgartirdi?", False),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Birgalikdagi mehnat qanday natija berdi?", False),
            (MaterialQuestion.QuestionType.VALUE_SELECT, "Rivoyatda qaysi qadriyatlar bir-biri bilan bog'langan?", True),
            (MaterialQuestion.QuestionType.OPEN_TEXT, "Sizningcha, barcha ishni ham yolg'iz bajarish mumkinmi? Misol bilan fikringizni asoslang.", False),
        ]
        for i, (qtype, text, multi) in enumerate(questions, start=1):
            MaterialQuestion.objects.create(
                material=material, question_text=text, question_type=qtype,
                allow_multiple_values=multi, display_order=i,
            )
        self.stdout.write(self.style.SUCCESS(f"2-material tayyor: '{material.title}' (5-savol: bir nechta qadriyat tanlash mumkin)"))
