from django.urls import path

from . import views

app_name = "heritage"

urlpatterns = [
    path(
        "materials/<int:material_id>/start/",
        views.StartOrResumeSubmissionView.as_view(),
        name="start-or-resume",
    ),
    path(
        "submissions/<int:submission_id>/video-progress/",
        views.VideoProgressView.as_view(),
        name="video-progress",
    ),
    path(
        "submissions/<int:submission_id>/answer/",
        views.SubmitAnswerView.as_view(),
        name="submit-answer",
    ),
]
