from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import HeritageMaterial, ValueAnalysisAnswer, ValueAnalysisSubmission
from .serializers import (
    AnswerSubmitSerializer,
    ValueAnalysisSubmissionSerializer,
    VideoProgressSerializer,
)

# Video pleyer taxminan har necha soniyada progress yuborishi kutiladi.
# Bundan ancha katta sakrash — forward-seek urinishi deb hisoblanadi.
PROGRESS_UPDATE_TOLERANCE_SECONDS = 10
# Video "tugadi" deb hisoblanishi uchun kamida shuncha foizi ko'rilgan bo'lishi kerak.
COMPLETION_THRESHOLD_RATIO = 0.95


class IsStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_student())


class StartOrResumeSubmissionView(APIView):
    """
    O'quvchi materialni ochganda chaqiriladi.
    Mavjud submission bo'lsa uni qaytaradi (video to'xtagan joyidan davom etadi),
    bo'lmasa yangisini yaratadi.

    Eslatma: `assigned_by` maydoni keyingi bosqichda Assignment modeli qo'shilganda
    o'sha yerdan to'ldiriladi; hozircha bo'sh (None) qoldiriladi.
    """

    permission_classes = [IsStudent]

    def post(self, request, material_id):
        material = get_object_or_404(HeritageMaterial, id=material_id, is_active=True)
        submission, _ = ValueAnalysisSubmission.objects.get_or_create(
            student=request.user,
            material=material,
            assigned_by=None,
        )
        return Response(ValueAnalysisSubmissionSerializer(submission).data)


class VideoProgressView(APIView):
    """
    Video pleyer bu endpoint'ga muntazam ravishda (masalan har 5 soniyada) progress yuboradi.
    Forward-seek bloklanadi: kutilganidan ancha katta sakrash qabul qilinmaydi.
    Internet uzilib qolsa ham, oxirgi saqlangan progress bazada saqlanib qoladi —
    o'quvchi qaytib kelganda shu joydan davom etadi.
    """

    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(
            ValueAnalysisSubmission, id=submission_id, student=request.user,
        )
        if submission.status == ValueAnalysisSubmission.Status.COMPLETED:
            return Response({"detail": "Bu topshiriq allaqachon yakunlangan."},
                             status=status.HTTP_400_BAD_REQUEST)

        serializer = VideoProgressSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        new_progress = serializer.validated_data["progress_seconds"]
        old_progress = submission.video_progress_seconds

        if new_progress > old_progress + PROGRESS_UPDATE_TOLERANCE_SECONDS:
            # Forward-seek urinishi — qabul qilinmaydi, faqat qayd etiladi.
            submission.seek_attempts_count += 1
            submission.save(update_fields=["seek_attempts_count"])
            return Response(
                {
                    "detail": "Videoni oldinga surib bo'lmaydi.",
                    "accepted_progress_seconds": old_progress,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Orqaga qaytish yoki normal (kutilgan tezlikdagi) oldinga siljish qabul qilinadi.
        submission.video_progress_seconds = max(old_progress, new_progress)
        submission.save(update_fields=["video_progress_seconds"])

        duration = submission.material.video_duration_seconds
        if duration and submission.video_progress_seconds >= duration * COMPLETION_THRESHOLD_RATIO:
            if not submission.video_completed_at:
                submission.video_completed_at = timezone.now()
                submission.save(update_fields=["video_completed_at"])

        submission.refresh_status()
        return Response(ValueAnalysisSubmissionSerializer(submission).data)


class SubmitAnswerView(APIView):
    """
    Navbatdagi savolga javob yuborish. Ketma-ketlik va video-tugallanganlik
    ValueAnalysisAnswer.clean() ichida backend darajasida tekshiriladi —
    frontend buni chetlab o'ta olmaydi.
    """

    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(
            ValueAnalysisSubmission, id=submission_id, student=request.user,
        )
        serializer = AnswerSubmitSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        answer = ValueAnalysisAnswer(
            submission=submission,
            question=data["question"],
            answer_text=data.get("answer_text", ""),
            selected_value_tags=data.get("selected_value_tags", []),
        )
        try:
            answer.save()
        except DjangoValidationError as e:
            return Response({"detail": e.messages}, status=status.HTTP_400_BAD_REQUEST)

        return Response(ValueAnalysisSubmissionSerializer(submission).data)
