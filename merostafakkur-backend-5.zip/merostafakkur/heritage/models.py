from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


class HeritageMaterial(models.Model):
    """Meros namunasi: maqol, rivoyat, hikmatli so'z, ibratli voqea yoki tarixiy lavha."""

    class MaterialType(models.TextChoices):
        PROVERB = "proverb", "Maqol"
        LEGEND = "legend", "Rivoyat"
        WISDOM = "wisdom", "Hikmatli so'z"
        MORAL_STORY = "moral_story", "Ibratli voqea"
        HISTORICAL = "historical", "Tarixiy shaxs lavhasi"

    class AgeGroup(models.TextChoices):
        GRADE_1_2 = "1-2", "1-2 sinf"
        GRADE_3_4 = "3-4", "3-4 sinf"

    title = models.CharField(max_length=255)
    type = models.CharField(max_length=20, choices=MaterialType.choices)
    age_group = models.CharField(max_length=10, choices=AgeGroup.choices)
    body_text = models.TextField(help_text="Rivoyat/material matni — video bilan bir vaqtda ko'rsatiladi")
    video_url = models.URLField(blank=True, help_text="Material videosi")
    video_duration_seconds = models.PositiveIntegerField(
        default=0, help_text="Video umumiy davomiyligi — 'tugadi' holatini tekshirish uchun",
    )
    value_tags = models.JSONField(
        default=list, blank=True,
        help_text="Bog'liq qadriyatlar ro'yxati, masalan: ['halollik', 'mehr-oqibat']",
    )
    source = models.CharField(max_length=255, blank=True, help_text="Manba: xalq og'zaki ijodi / muallif")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class MaterialQuestion(models.Model):
    """
    Har bir materialning o'z savollar to'plami bor — soni va turi materialdan
    materialga farq qilishi mumkin (masalan bitta material 5 ta, boshqasi 6 ta savolga ega
    bo'lishi mumkin).
    """

    class QuestionType(models.TextChoices):
        OPEN_TEXT = "open_text", "Erkin matn"
        VALUE_SELECT = "value_select", "Qadriyat tanlash (material.value_tags dan)"

    material = models.ForeignKey(HeritageMaterial, on_delete=models.CASCADE, related_name="questions")
    question_text = models.TextField()
    question_type = models.CharField(
        max_length=20, choices=QuestionType.choices, default=QuestionType.OPEN_TEXT,
    )
    allow_multiple_values = models.BooleanField(
        default=False,
        help_text="value_select turi uchun: bir nechta qadriyat tanlash mumkinmi (checkbox) yoki faqat bittami",
    )
    display_order = models.PositiveIntegerField(help_text="Savol ochilish tartibi, 1 dan boshlab")

    class Meta:
        ordering = ["material", "display_order"]
        unique_together = ("material", "display_order")

    def __str__(self):
        return f"{self.material.title} — savol {self.display_order}"


class ValueAnalysisSubmission(models.Model):
    """O'quvchining bitta materialga bergan javoblari to'plami (bitta 'urinish')."""

    class Status(models.TextChoices):
        NOT_STARTED = "not_started", "Boshlanmagan"
        WATCHING = "watching", "Video ko'rilmoqda"
        ANSWERING = "answering", "Savollarga javob berilmoqda"
        COMPLETED = "completed", "Yakunlangan"

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="value_analysis_submissions",
    )
    material = models.ForeignKey(HeritageMaterial, on_delete=models.CASCADE, related_name="submissions")
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="assigned_value_analyses",
    )
    cycle = models.ForeignKey(
        "cycles.ValueCycle", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="value_analysis_submissions",
    )
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NOT_STARTED)

    # Video nazorati
    video_progress_seconds = models.FloatField(default=0)
    video_completed_at = models.DateTimeField(null=True, blank=True)
    seek_attempts_count = models.PositiveIntegerField(default=0)

    teacher_feedback = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("student", "material", "assigned_by")

    def __str__(self):
        return f"{self.student} — {self.material.title} ({self.get_status_display()})"

    # ---- Biznes mantiq: ketma-ketlikni backend darajasida ta'minlash ----

    def can_answer_questions(self):
        """Savollarga javob berish faqat video tugagandan keyin ochiladi."""
        return self.video_completed_at is not None

    def next_unanswered_question(self):
        """Navbatdagi ochilishi kerak bo'lgan savolni qaytaradi (ketma-ketlik shu yerda ta'minlanadi)."""
        answered_ids = self.answers.values_list("question_id", flat=True)
        return (
            self.material.questions.exclude(id__in=answered_ids).order_by("display_order").first()
        )

    def refresh_status(self):
        if self.status == self.Status.COMPLETED:
            return
        if not self.video_completed_at:
            self.status = self.Status.WATCHING if self.video_progress_seconds > 0 else self.Status.NOT_STARTED
        elif self.next_unanswered_question() is None:
            self.status = self.Status.COMPLETED
        else:
            self.status = self.Status.ANSWERING
        self.save(update_fields=["status", "updated_at"])


class ValueAnalysisAnswer(models.Model):
    """Bitta savolga berilgan bitta javob — har savol alohida yozuv sifatida saqlanadi."""

    submission = models.ForeignKey(
        ValueAnalysisSubmission, on_delete=models.CASCADE, related_name="answers",
    )
    question = models.ForeignKey(MaterialQuestion, on_delete=models.CASCADE, related_name="answers")

    answer_text = models.TextField(blank=True, help_text="open_text turidagi savollar uchun")
    selected_value_tags = models.JSONField(
        default=list, blank=True,
        help_text="value_select turidagi savollar uchun — bitta bo'lsa ham ro'yxat sifatida saqlanadi",
    )
    answered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("submission", "question")

    def clean(self):
        # Savol tegishli materialga tegishli ekanini va oldingi savollar
        # javoblangan bo'lishini backend darajasida tekshiramiz.
        if self.question.material_id != self.submission.material_id:
            raise ValidationError("Savol boshqa materialga tegishli.")
        if not self.submission.can_answer_questions():
            raise ValidationError("Video hali tugamagan — savolga javob berib bo'lmaydi.")
        expected = self.submission.next_unanswered_question()
        if expected is None or expected.id != self.question_id:
            raise ValidationError(
                "Savollar ketma-ket ochiladi — bu savolga hali navbat kelmagan."
            )
        if self.question.question_type == MaterialQuestion.QuestionType.VALUE_SELECT:
            if not self.selected_value_tags:
                raise ValidationError("Kamida bitta qadriyat tanlanishi kerak.")
            if not self.question.allow_multiple_values and len(self.selected_value_tags) > 1:
                raise ValidationError("Bu savolda faqat bitta qadriyat tanlash mumkin.")

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)
        self.submission.refresh_status()
