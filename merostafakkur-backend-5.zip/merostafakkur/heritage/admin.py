from django.contrib import admin

from .models import (
    HeritageMaterial,
    MaterialQuestion,
    ValueAnalysisAnswer,
    ValueAnalysisSubmission,
)


class MaterialQuestionInline(admin.TabularInline):
    model = MaterialQuestion
    extra = 1
    ordering = ["display_order"]


@admin.register(HeritageMaterial)
class HeritageMaterialAdmin(admin.ModelAdmin):
    list_display = ["title", "type", "age_group", "is_active", "created_at"]
    list_filter = ["type", "age_group", "is_active"]
    search_fields = ["title", "body_text"]
    inlines = [MaterialQuestionInline]


class ValueAnalysisAnswerInline(admin.TabularInline):
    model = ValueAnalysisAnswer
    extra = 0
    readonly_fields = ["question", "answer_text", "selected_value_tags", "answered_at"]
    can_delete = False


@admin.register(ValueAnalysisSubmission)
class ValueAnalysisSubmissionAdmin(admin.ModelAdmin):
    """
    O'qituvchi bu yerda o'quvchi javoblarini — tanlov, asoslash va h.k. — birgalikda,
    bitta 'hikoya' ko'rinishida ko'radi (inline orqali).
    """

    list_display = ["student", "material", "status", "video_completed_at", "updated_at"]
    list_filter = ["status", "material"]
    search_fields = ["student__username", "student__first_name", "student__last_name"]
    readonly_fields = [
        "video_progress_seconds", "video_completed_at", "seek_attempts_count",
        "created_at", "updated_at",
    ]
    inlines = [ValueAnalysisAnswerInline]
