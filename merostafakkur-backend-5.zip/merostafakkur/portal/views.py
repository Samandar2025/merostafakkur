import re

from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.shortcuts import redirect, render

from accounts.models import ClassStudent, School, SchoolClass, User
from assignments.models import Assignment
from assignments.status import MODULE_LABELS, STATUS_LABELS, get_assignment_status


def _make_student_username(name):
    """Ism asosida bo'sh (band qilinmagan) username hosil qiladi."""
    base = re.sub(r"[^a-z0-9]+", "", name.lower()) or "oquvchi"
    username = base
    n = 1
    while User.objects.filter(username=username).exists():
        n += 1
        username = f"{base}{n}"
    return username


def _get_default_class():
    """
    O'zi ism yozib ro'yxatdan o'tgan o'quvchilar tushadigan standart sinf.
    Admin keyinchalik bu o'quvchilarni haqiqiy sinfga ko'chirishi mumkin.
    """
    school, _ = School.objects.get_or_create(name="Standart maktab")
    school_class, _ = SchoolClass.objects.get_or_create(
        school=school, name="Standart sinf",
    )
    return school_class


def student_login_view(request):
    """
    O'quvchi faqat o'z ISMINI yozib kiradi — boshqa hech narsa kerak emas.
    Admin oldindan ro'yxatga olishi shart emas: shu ism bilan hech kim
    topilmasa, tizim shu o'quvchi uchun yangi hisob avtomatik yaratadi.
    Agar bir xil ismli bir nechta o'quvchi topilsa, ro'yxatdan tanlash
    so'raladi (README'da yozilgan xatti-harakat).
    Diqqat: bu past-xavfsizlikli kirish usuli — istalgan kishi istalgan
    ismni yozib kirishi mumkin. Bu ataylab shunday qilingan (foydalanuvchi
    so'roviga ko'ra).
    """
    error = None
    candidates = None
    submitted_name = ""

    if request.method == "POST":
        submitted_name = request.POST.get("student_name", "").strip()
        student_id = request.POST.get("student_id")

        if student_id:
            # Foydalanuvchi tanlash ro'yxatidan birini bosdi.
            user = User.objects.filter(
                pk=student_id, role=User.Role.STUDENT, is_active=True,
                first_name__iexact=submitted_name,
            ).first()
            if user is None:
                error = "Bu o'quvchi topilmadi. Qaytadan urinib ko'ring."
            else:
                login(request, user, backend="django.contrib.auth.backends.ModelBackend")
                return redirect("portal:home")
        elif not submitted_name:
            error = "Iltimos, ismingizni kiriting."
        else:
            matches = list(User.objects.filter(
                role=User.Role.STUDENT, is_active=True, first_name__iexact=submitted_name,
            ).order_by("last_name", "id"))

            if not matches:
                # Bu ism bilan hech kim yo'q — yangi o'quvchi hisobini
                # o'zimiz yaratamiz, standart sinfga qo'shamiz va darhol
                # tizimga kiritamiz.
                user = User.objects.create_user(
                    username=_make_student_username(submitted_name),
                    first_name=submitted_name,
                    role=User.Role.STUDENT,
                )
                ClassStudent.objects.create(
                    school_class=_get_default_class(), student=user,
                )
                login(request, user, backend="django.contrib.auth.backends.ModelBackend")
                return redirect("portal:home")
            elif len(matches) == 1:
                login(request, matches[0], backend="django.contrib.auth.backends.ModelBackend")
                return redirect("portal:home")
            else:
                # Bir xil ismli bir nechta o'quvchi — tanlash ro'yxatini ko'rsatamiz.
                for m in matches:
                    membership = m.class_memberships.select_related(
                        "school_class__school"
                    ).first()
                    m.class_label = str(membership.school_class) if membership else ""
                candidates = matches

    return render(request, "portal/login.html", {
        "error": error,
        "candidates": candidates,
        "submitted_name": submitted_name,
    })


def logout_view(request):
    logout(request)
    return redirect("portal:login")


@login_required(login_url="portal:login")
def student_home_view(request):
    if not request.user.is_student():
        raise PermissionDenied("Bu sahifa faqat o'quvchilar uchun.")

    assignments = Assignment.objects.filter(
        Q(assigned_to_student=request.user)
        | Q(assigned_to_class__students__student=request.user)
    ).distinct().select_related("content_type")

    items = []
    for a in assignments:
        model_name = a.content_type.model
        label, _ = MODULE_LABELS.get(model_name, ("Noma'lum modul", ""))
        status = get_assignment_status(a, request.user)
        items.append({
            "title": str(a.content_object) if a.content_object else "(o'chirilgan)",
            "module_label": label,
            "status": status,
            "status_label": STATUS_LABELS.get(status, status),
            "is_done": status == "completed",
        })

    # Yangi bajarilishi kerak bo'lganlar tepada
    items.sort(key=lambda x: x["is_done"])

    return render(request, "portal/home.html", {
        "student": request.user,
        "items": items,
        "pending_count": sum(1 for i in items if not i["is_done"]),
    })
