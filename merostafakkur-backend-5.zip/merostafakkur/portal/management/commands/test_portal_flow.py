from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand
from django.test import Client

from accounts.models import ClassStudent, School, SchoolClass, User
from assignments.models import Assignment
from dilemmas.models import MoralDilemma
from heritage.models import HeritageMaterial
from heritage.views import StartOrResumeSubmissionView, SubmitAnswerView, VideoProgressView
from kindness.models import KindnessTask
from rest_framework.test import APIRequestFactory, force_authenticate


class Command(BaseCommand):
    help = "Portal (ism bilan kirish + bosh sahifa + Assignment) to'liq oqimini sinaydi"

    def handle(self, *args, **options):
        # ---- Tayyorgarlik: o'qituvchi, o'quvchilar (ikkitasi bir xil ism!), sinf ----
        teacher, _ = User.objects.get_or_create(
            username="test_teacher_portal", defaults={"role": User.Role.TEACHER}
        )
        student1, _ = User.objects.get_or_create(
            username="test_student_portal1",
            defaults={"role": User.Role.STUDENT, "first_name": "Aziz", "last_name": "Karimov"},
        )
        student2, _ = User.objects.get_or_create(
            username="test_student_portal2",
            defaults={"role": User.Role.STUDENT, "first_name": "Malika", "last_name": "Yusupova"},
        )
        # Bir xil ismli UCHINCHI o'quvchi — disambiguatsiya holatini sinash uchun
        student1_dup, _ = User.objects.get_or_create(
            username="test_student_portal1_dup",
            defaults={"role": User.Role.STUDENT, "first_name": "Aziz", "last_name": "Rahimov"},
        )

        school, _ = School.objects.get_or_create(name="Test maktabi")
        school_class, _ = SchoolClass.objects.get_or_create(school=school, name="2-A", teacher=teacher)
        ClassStudent.objects.get_or_create(school_class=school_class, student=student2)

        material = HeritageMaterial.objects.first()
        dilemma = MoralDilemma.objects.first()

        Assignment.objects.get_or_create(
            assigned_by=teacher, assigned_to_student=student1, assigned_to_class=None,
            content_type=ContentType.objects.get_for_model(HeritageMaterial), object_id=material.id,
        )
        Assignment.objects.get_or_create(
            assigned_by=teacher, assigned_to_student=None, assigned_to_class=school_class,
            content_type=ContentType.objects.get_for_model(MoralDilemma), object_id=dilemma.id,
        )

        client = Client()

        # ---- 1) Mavjud bo'lmagan ism bilan kirishga urinish ----
        self.stdout.write("1) Mavjud bo'lmagan ism bilan kirish...")
        resp = client.post("/login/", {"student_name": "Sarvinoz"})
        assert resp.status_code == 200
        assert "topilmadi" in resp.content.decode()
        self.stdout.write("   ✓ To'g'ri: 'topilmadi' xabari ko'rsatildi")

        # ---- 2) Bir xil ismli o'quvchilar bo'lsa ham, birinchisi bilan to'g'ridan-to'g'ri kiradi ----
        self.stdout.write("\n2) Bir xil ismli o'quvchi (Aziz) bilan kirish — to'g'ridan-to'g'ri kirishi kerak...")
        resp = client.post("/login/", {"student_name": "Aziz"}, follow=True)
        assert resp.wsgi_request.path == "/"
        self.stdout.write("   ✓ To'g'ri: qo'shimcha so'rovsiz kirdi")

        # ---- 3) Bosh sahifada faqat OZ topshirig'ini ko'rishi kerak ----
        self.stdout.write("\n3) Bosh sahifa tarkibini tekshirish (Aziz Karimov)...")
        from django.utils.html import escape
        content = resp.content.decode()
        assert escape(material.title) in content, "student1 o'ziga biriktirilgan materialni ko'rmadi!"
        assert escape(dilemma.title) not in content, "student1 boshqa sinfga tegishli vaziyatni ko'rib qo'ydi!"
        assert "Boshlanmagan" in content
        self.stdout.write("   ✓ Faqat o'ziga tegishli topshiriq ko'rindi, holati 'Boshlanmagan'")

        # ---- 4) Materialni bajarib, holat yangilanishini tekshirish ----
        self.stdout.write("\n4) Materialni to'liq bajarib, sahifani qayta yuklaymiz...")
        material.video_duration_seconds = 30
        material.save()
        factory = APIRequestFactory()

        def call(view_cls, method_name, path, data, user, **kwargs):
            req = getattr(factory, method_name)(path, data, format="json")
            force_authenticate(req, user=user)
            return view_cls.as_view()(req, **kwargs)

        resp2 = call(StartOrResumeSubmissionView, "post", "/start/", {}, student1, material_id=material.id)
        hsid = resp2.data["id"]
        for sec in range(10, 31, 10):
            call(VideoProgressView, "post", "/progress/", {"progress_seconds": sec}, student1, submission_id=hsid)
        for q in material.questions.order_by("display_order"):
            data = {"question_id": q.id}
            if q.question_type == "value_select":
                data["selected_value_tags"] = [material.value_tags[0]]
            else:
                data["answer_text"] = "Test javobi."
            call(SubmitAnswerView, "post", "/answer/", data, student1, submission_id=hsid)

        resp = client.get("/")
        content = resp.content.decode()
        assert "Bajarildi" in content
        self.stdout.write("   ✓ Bosh sahifada holat 'Bajarildi ✅' ga yangilandi")

        # ---- 5) student2 (bitta ism, disambiguatsiyasiz) sinf orqali topshiriqni ko'rishi ----
        self.stdout.write("\n5) Chiqib, Malika (yagona ism) bilan kirish...")
        client.get("/logout/")
        resp = client.post("/login/", {"student_name": "Malika"}, follow=True)
        content = resp.content.decode()
        assert escape(dilemma.title) in content, "student2 sinfga biriktirilgan vaziyatni ko'rmadi!"
        assert escape(material.title) not in content, "student2 boshqa o'quvchiga tegishli materialni ko'rib qo'ydi!"
        self.stdout.write("   ✓ To'g'ri: bitta ism bo'lgani uchun to'g'ridan-to'g'ri kirdi, o'z ishini ko'rdi")

        # ---- 6) Login qilmasdan bosh sahifaga kirishga urinish ----
        self.stdout.write("\n6) Chiqib, login qilmasdan bosh sahifaga kirishga urinish...")
        client.get("/logout/")
        resp = client.get("/", follow=True)
        assert "student_name" in resp.content.decode() or resp.redirect_chain, "Himoyalanmagan sahifaga kirib bo'ldi!"
        self.stdout.write("   ✓ To'g'ri: login sahifasiga yo'naltirildi")

        self.stdout.write(self.style.SUCCESS("\nPortal (ism bilan kirish + bosh sahifa + Assignment) to'liq ishlayapti ✅"))
