from django.urls import path

from . import views

app_name = "portal"

urlpatterns = [
    path("login/", views.student_login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("", views.student_home_view, name="home"),
]
