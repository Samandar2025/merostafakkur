from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import get_object_or_404
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import KindnessSubmission, KindnessTask
from .serializers import (
    KindnessSubmissionSerializer,
    TeacherFeedbackSerializer,
    TextAnswerSerializer,
)


class IsStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_student())


class IsTeacher(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_teacher())


class StartOrResumeKindnessView(APIView):
    permission_classes = [IsStudent]

    def post(self, request, task_id):
        task = get_object_or_404(KindnessTask, id=task_id, is_active=True)
        submission, _ = KindnessSubmission.objects.get_or_create(
            student=request.user, task=task, assigned_by=None,
        )
        return Response(KindnessSubmissionSerializer(submission).data)


def _handle(fn, *args):
    try:
        fn(*args)
        return None
    except DjangoValidationError as e:
        return Response({"detail": e.messages}, status=status.HTTP_400_BAD_REQUEST)


class CommitView(APIView):
    """'Bajarishga kirishaman' — real ishni boshlashdan oldin bosiladi."""

    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(KindnessSubmission, id=submission_id, student=request.user)
        err = _handle(submission.commit)
        if err:
            return err
        return Response(KindnessSubmissionSerializer(submission).data)


class SubmitQ1View(APIView):
    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(KindnessSubmission, id=submission_id, student=request.user)
        s = TextAnswerSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        err = _handle(submission.submit_q1, s.validated_data["text"])
        if err:
            return err
        return Response(KindnessSubmissionSerializer(submission).data)


class SubmitQ2View(APIView):
    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(KindnessSubmission, id=submission_id, student=request.user)
        s = TextAnswerSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        err = _handle(submission.submit_q2, s.validated_data["text"])
        if err:
            return err
        return Response(KindnessSubmissionSerializer(submission).data)


class SubmitQ3View(APIView):
    """Bu bosqich bilan submission avtomatik 'completed' holatiga o'tadi."""

    permission_classes = [IsStudent]

    def post(self, request, submission_id):
        submission = get_object_or_404(KindnessSubmission, id=submission_id, student=request.user)
        s = TextAnswerSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        err = _handle(submission.submit_q3, s.validated_data["text"])
        if err:
            return err
        return Response(KindnessSubmissionSerializer(submission).data)


class MarkReviewedView(APIView):
    """O'qituvchi: 'recorded' -> 'reviewed'. To'g'ri/noto'g'ri tugmasi emas."""

    permission_classes = [IsTeacher]

    def post(self, request, submission_id):
        submission = get_object_or_404(KindnessSubmission, id=submission_id)
        err = _handle(submission.mark_reviewed)
        if err:
            return err
        return Response(KindnessSubmissionSerializer(submission).data)


class GiveFeedbackView(APIView):
    """O'qituvchi qisqa pedagogik fikr yozadi — holat avtomatik 'feedback_given'ga o'tadi."""

    permission_classes = [IsTeacher]

    def post(self, request, submission_id):
        submission = get_object_or_404(KindnessSubmission, id=submission_id)
        s = TeacherFeedbackSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        err = _handle(submission.give_feedback, s.validated_data["feedback_text"])
        if err:
            return err
        return Response(KindnessSubmissionSerializer(submission).data)
