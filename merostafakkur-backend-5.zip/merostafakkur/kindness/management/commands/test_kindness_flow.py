from django.core.management.base import BaseCommand
from rest_framework.test import APIRequestFactory, force_authenticate

from accounts.models import User
from kindness.models import KindnessTask
from kindness.views import (
    CommitView,
    GiveFeedbackView,
    MarkReviewedView,
    StartOrResumeKindnessView,
    SubmitQ1View,
    SubmitQ2View,
    SubmitQ3View,
)


class Command(BaseCommand):
    help = "3-modul oqimini sinaydi: kirishaman -> q1 -> q2 -> q3 -> o'qituvchi fikri"

    def handle(self, *args, **options):
        student, _ = User.objects.get_or_create(
            username="test_student_m3", defaults={"role": User.Role.STUDENT}
        )
        teacher, _ = User.objects.get_or_create(
            username="test_teacher_m3", defaults={"role": User.Role.TEACHER}
        )
        task = KindnessTask.objects.get(title="Merosdan hayotga: Mehr-oqibat")
        factory = APIRequestFactory()

        def call(view_cls, method_name, path, data, user, **kwargs):
            req = getattr(factory, method_name)(path, data, format="json")
            force_authenticate(req, user=user)
            return view_cls.as_view()(req, **kwargs)

        self.stdout.write("1) Submission boshlanmoqda...")
        resp = call(StartOrResumeKindnessView, "post", "/start/", {}, student, task_id=task.id)
        self.stdout.write(f"   status={resp.status_code} holat={resp.data['status']}")
        sid = resp.data["id"]

        self.stdout.write("\n2) Q1 ni COMMIT'DAN OLDIN yuborishga urinish (rad etilishi kerak)...")
        resp = call(SubmitQ1View, "post", "/q1/", {"text": "Tartib buzish"}, student, submission_id=sid)
        self.stdout.write(f"   status={resp.status_code} data={resp.data}")
        assert resp.status_code == 400

        self.stdout.write("\n3) 'Bajarishga kirishaman' bosilmoqda...")
        resp = call(CommitView, "post", "/commit/", {}, student, submission_id=sid)
        self.stdout.write(f"   status={resp.status_code} committed_at={resp.data['committed_at'] is not None}")

        self.stdout.write("\n4) Commit'ni QAYTA bosishga urinish (rad etilishi kerak)...")
        resp = call(CommitView, "post", "/commit/", {}, student, submission_id=sid)
        assert resp.status_code == 400
        self.stdout.write(f"   status={resp.status_code} ✓ to'g'ri rad etildi")

        self.stdout.write("\n5) Q1 to'g'ri tartibda yuborilmoqda...")
        resp = call(SubmitQ1View, "post", "/q1/", {"text": "Buvimga gullarga suv quyishda yordam berdim."}, student, submission_id=sid)
        self.stdout.write(f"   status={resp.status_code} holat={resp.data['status']}")

        self.stdout.write("\n6) Q3 ni Q2'DAN OLDIN yuborishga urinish (rad etilishi kerak)...")
        resp = call(SubmitQ3View, "post", "/q3/", {"text": "Tartib buzish"}, student, submission_id=sid)
        assert resp.status_code == 400
        self.stdout.write(f"   status={resp.status_code} ✓ to'g'ri rad etildi")

        self.stdout.write("\n7) Q2 yuborilmoqda...")
        resp = call(SubmitQ2View, "post", "/q2/", {"text": "Buvim uchun."}, student, submission_id=sid)
        self.stdout.write(f"   status={resp.status_code} holat={resp.data['status']}")

        self.stdout.write("\n8) Q3 yuborilmoqda (yakunlanishi kerak)...")
        resp = call(SubmitQ3View, "post", "/q3/", {"text": "Gullarga suv quyildi, buvimning ishi yengillashdi."}, student, submission_id=sid)
        self.stdout.write(f"   status={resp.status_code} yakuniy_holat={resp.data['status']} submitted_at bor={resp.data['submitted_at'] is not None}")
        assert resp.data["status"] == "completed"

        self.stdout.write("\n9) O'qituvchi to'g'ridan-to'g'ri FIKR YOZADI (review bosmasdan)...")
        resp = call(GiveFeedbackView, "post", "/feedback/",
                     {"feedback_text": "Yordamni o'zingiz taklif qilganingiz yaxshi."},
                     teacher, submission_id=sid)
        self.stdout.write(f"   status={resp.status_code} teacher_status={resp.data['teacher_status']}")
        assert resp.data["teacher_status"] == "feedback_given", "Muammo #3 tuzatilmagan!"
        self.stdout.write("   ✓ Muammo #3 tuzatilgan: alohida 'review' bosilmasa ham holat to'g'ri o'tdi")

        self.stdout.write(self.style.SUCCESS("\n3-modul oqimi to'liq va to'g'ri ishlayapti ✅"))
