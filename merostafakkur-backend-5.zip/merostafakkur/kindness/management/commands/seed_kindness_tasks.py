from django.core.management.base import BaseCommand

from kindness.models import KindnessTask
from valuesapp.models import Value

TASKS = [
    ("Mehr-oqibat",
     "Bugun sinfda yoki oilada yordamga ehtiyoji bor kishiga bitta aniq ishda ko'maklashing."),
    ("Kattalarga hurmat",
     "Bugun bobo-buvingiz, ota-onangiz yoki yoshi katta yaqin insoningizga yordam beradigan "
     "bitta ishni o'zingiz taklif qilib bajaring."),
    ("Mehnatsevarlik",
     "Sizga aytishlarini kutmasdan sinf yoki uydagi bajarilishi zarur bo'lgan bir foydali "
     "ishni bajaring."),
    ("Tejamkorlik",
     "Bugun suv, elektr energiyasi, qog'oz yoki oziq-ovqatni isrof qilmaslikka qaratilgan "
     "bitta aniq harakatni amalga oshiring."),
    ("Hamjihatlik",
     "Sinfdoshlaringiz yoki oila a'zolaringiz bilan umumiy foydali ishning bir qismini "
     "birgalikda bajaring."),
    ("Tabiatga g'amxo'rlik",
     "O'simlikni parvarish qilish, atrofni ozoda saqlash yoki tabiatga foydali boshqa bir "
     "ishni bajaring."),
    ("Mas'uliyat",
     "Bugun o'zingizga tegishli vazifalardan birini eslatishsiz va o'z vaqtida bajaring."),
    ("Do'stlik",
     "Sinfdoshingizga o'qish yoki boshqa foydali faoliyatda yordam bering, lekin uning "
     "o'rniga vazifani bajarib bermang."),
    ("Ne'matni qadrlash",
     "Bugun ovqat yoki nonni isrof qilmaslikka ongli ravishda e'tibor bering va bunga mos "
     "bitta harakatni bajaring."),
    ("Obodonchilik",
     "Sinf, uy yoki hovlingizni ozoda va tartibli saqlashga qaratilgan bitta ishni bajaring."),
]


class Command(BaseCommand):
    help = "3-modul uchun 10 ta 'Merosdan hayotga' topshirig'ini bazaga kiritadi"

    def handle(self, *args, **options):
        for value_name, instruction in TASKS:
            try:
                value = Value.objects.get(name=value_name)
            except Value.DoesNotExist:
                self.stderr.write(self.style.ERROR(
                    f"  ✗ Qadriyat topilmadi: '{value_name}' — avval 'seed_values' ni ishga tushiring."
                ))
                continue
            task, _ = KindnessTask.objects.update_or_create(
                value=value,
                defaults={
                    "title": f"Merosdan hayotga: {value_name}",
                    "instruction_text": instruction,
                    "age_group": "1-2",
                },
            )
            self.stdout.write(f"  ✓ {task.title}")
        self.stdout.write(self.style.SUCCESS(f"\n{len(TASKS)} ta topshiriq tayyor."))
