from django.urls import path

from . import views

app_name = "kindness"

urlpatterns = [
    path("tasks/<int:task_id>/start/", views.StartOrResumeKindnessView.as_view(), name="start"),
    path("submissions/<int:submission_id>/commit/", views.CommitView.as_view(), name="commit"),
    path("submissions/<int:submission_id>/q1/", views.SubmitQ1View.as_view(), name="q1"),
    path("submissions/<int:submission_id>/q2/", views.SubmitQ2View.as_view(), name="q2"),
    path("submissions/<int:submission_id>/q3/", views.SubmitQ3View.as_view(), name="q3"),
    path("submissions/<int:submission_id>/review/", views.MarkReviewedView.as_view(), name="review"),
    path("submissions/<int:submission_id>/feedback/", views.GiveFeedbackView.as_view(), name="feedback"),
]
