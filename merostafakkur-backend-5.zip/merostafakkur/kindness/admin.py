from django.contrib import admin

from .models import KindnessSubmission, KindnessTask


@admin.register(KindnessTask)
class KindnessTaskAdmin(admin.ModelAdmin):
    list_display = ["title", "value", "age_group", "is_active"]
    list_filter = ["value", "age_group", "is_active"]
    search_fields = ["title", "instruction_text"]


@admin.register(KindnessSubmission)
class KindnessSubmissionAdmin(admin.ModelAdmin):
    list_display = ["student", "task", "status", "teacher_status", "updated_at"]
    list_filter = ["status", "teacher_status", "task"]
    search_fields = ["student__username"]
    readonly_fields = [
        "committed_at", "what_i_did_text", "q1_answered_at",
        "with_whom_text", "q2_answered_at", "result_text", "q3_answered_at",
        "submitted_at", "created_at", "updated_at",
    ]
