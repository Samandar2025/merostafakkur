from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

from valuesapp.models import Value


class KindnessTask(models.Model):
    """
    "Merosdan hayotga" amaliy topshirig'i. Tasodifiy ro'yxat emas —
    har biri markazlashtirilgan Value jadvaliga bog'langan, shu orqali
    1 va 2-moduldagi mos qadriyat bilan Qadriyat sikli hosil qilinadi.
    """

    value = models.ForeignKey(Value, on_delete=models.PROTECT, related_name="kindness_tasks")
    title = models.CharField(max_length=255)
    instruction_text = models.TextField(help_text="Masalan: 'Bugun oilangizda...'")
    age_group = models.CharField(
        max_length=10,
        choices=[("1-2", "1-2 sinf"), ("3-4", "3-4 sinf")],
        default="1-2",
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.value.name})"


class KindnessSubmission(models.Model):
    """
    O'quvchining bitta amaliy topshiriq bo'yicha to'liq zanjiri:
    niyat bildirish -> (real hayotda bajarish, offline) -> 3 ta savol -> yakunlash.
    Ketma-ket, orqaga qaytarib bo'lmaydi — 1 va 2-moduldagi kabi.
    """

    class Status(models.TextChoices):
        NOT_STARTED = "not_started", "Boshlanmagan"
        COMMITTED = "committed", "Bajarishga kirishilgan"
        Q1 = "q1", "1-savol javoblangan"
        Q2 = "q2", "2-savol javoblangan"
        COMPLETED = "completed", "Yakunlangan"

    class TeacherStatus(models.TextChoices):
        RECORDED = "recorded", "Qayd etildi"
        REVIEWED = "reviewed", "Ko'rib chiqildi"
        FEEDBACK_GIVEN = "feedback_given", "Qayta aloqa berildi"

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="kindness_submissions",
    )
    task = models.ForeignKey(KindnessTask, on_delete=models.CASCADE, related_name="submissions")
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="assigned_kindness_tasks",
    )
    # Qadriyat sikli bilan bog'lanish (ixtiyoriy) — 2-muammoning yechimi:
    # submission qaysi sikl doirasida bajarilganini biladi.
    cycle = models.ForeignKey(
        "cycles.ValueCycle", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="kindness_submissions",
    )

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.NOT_STARTED)

    committed_at = models.DateTimeField(null=True, blank=True, help_text="'Bajarishga kirishaman' bosilgan payt")

    what_i_did_text = models.TextField(blank=True)
    q1_answered_at = models.DateTimeField(null=True, blank=True)

    with_whom_text = models.TextField(blank=True)
    q2_answered_at = models.DateTimeField(null=True, blank=True)

    result_text = models.TextField(blank=True)
    q3_answered_at = models.DateTimeField(null=True, blank=True)

    submitted_at = models.DateTimeField(null=True, blank=True)

    # O'qituvchi tomoni — 3-muammoning yechimi: to'g'ri/noto'g'ri tugmasi yo'q,
    # faqat uch bosqichli holat, va feedback yozilsa avtomatik "feedback_given"ga o'tadi.
    teacher_status = models.CharField(
        max_length=20, choices=TeacherStatus.choices, default=TeacherStatus.RECORDED,
    )
    teacher_reviewed_at = models.DateTimeField(null=True, blank=True)
    teacher_feedback = models.TextField(blank=True)
    teacher_feedback_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("student", "task", "assigned_by")

    def __str__(self):
        return f"{self.student} — {self.task.title} ({self.get_status_display()})"

    # ---- O'quvchi tomoni: ketma-ketlik backend darajasida ta'minlanadi ----

    def commit(self):
        if self.committed_at is not None:
            raise ValidationError("Siz allaqachon 'Bajarishga kirishaman' deb belgilagansiz.")
        self.committed_at = timezone.now()
        self.status = self.Status.COMMITTED
        self.save(update_fields=["committed_at", "status", "updated_at"])

    def submit_q1(self, text):
        if self.committed_at is None:
            raise ValidationError("Avval 'Bajarishga kirishaman' tugmasini bosishingiz kerak.")
        if self.q1_answered_at is not None:
            raise ValidationError("1-savolga allaqachon javob bergansiz.")
        if not text or not text.strip():
            raise ValidationError("Javob bo'sh bo'lishi mumkin emas.")
        self.what_i_did_text = text.strip()
        self.q1_answered_at = timezone.now()
        self.status = self.Status.Q1
        self.save(update_fields=["what_i_did_text", "q1_answered_at", "status", "updated_at"])

    def submit_q2(self, text):
        if self.q1_answered_at is None:
            raise ValidationError("Avval 1-savolga javob berilishi kerak.")
        if self.q2_answered_at is not None:
            raise ValidationError("2-savolga allaqachon javob bergansiz.")
        if not text or not text.strip():
            raise ValidationError("Javob bo'sh bo'lishi mumkin emas.")
        self.with_whom_text = text.strip()
        self.q2_answered_at = timezone.now()
        self.status = self.Status.Q2
        self.save(update_fields=["with_whom_text", "q2_answered_at", "status", "updated_at"])

    def submit_q3(self, text):
        if self.q2_answered_at is None:
            raise ValidationError("Avval 2-savolga javob berilishi kerak.")
        if self.q3_answered_at is not None:
            raise ValidationError("3-savolga allaqachon javob bergansiz.")
        if not text or not text.strip():
            raise ValidationError("Javob bo'sh bo'lishi mumkin emas.")
        self.result_text = text.strip()
        now = timezone.now()
        self.q3_answered_at = now
        self.submitted_at = now
        self.status = self.Status.COMPLETED
        self.save(update_fields=["result_text", "q3_answered_at", "submitted_at", "status", "updated_at"])

    # ---- O'qituvchi tomoni ----

    def mark_reviewed(self):
        if self.submitted_at is None:
            raise ValidationError("Hali yakunlanmagan topshiriqni ko'rib chiqib bo'lmaydi.")
        if self.teacher_status == self.TeacherStatus.RECORDED:
            self.teacher_status = self.TeacherStatus.REVIEWED
            self.teacher_reviewed_at = timezone.now()
            self.save(update_fields=["teacher_status", "teacher_reviewed_at", "updated_at"])

    def give_feedback(self, text):
        if self.submitted_at is None:
            raise ValidationError("Hali yakunlanmagan topshiriqqa fikr-mulohaza berib bo'lmaydi.")
        if not text or not text.strip():
            raise ValidationError("Fikr-mulohaza matni bo'sh bo'lishi mumkin emas.")
        now = timezone.now()
        self.teacher_feedback = text.strip()
        self.teacher_feedback_at = now
        # Muammo #3 ning yechimi: fikr-mulohaza yozilishi bilanoq holat avtomatik
        # "feedback_given"ga o'tadi — o'qituvchi alohida "ko'rib chiqdim" tugmasini
        # bosishni unutib qo'ysa ham, holat nomuvofiq qolib ketmaydi.
        if self.teacher_reviewed_at is None:
            self.teacher_reviewed_at = now
        self.teacher_status = self.TeacherStatus.FEEDBACK_GIVEN
        self.save(update_fields=[
            "teacher_feedback", "teacher_feedback_at", "teacher_reviewed_at",
            "teacher_status", "updated_at",
        ])
