from rest_framework import serializers

from .models import KindnessSubmission, KindnessTask


class KindnessTaskSerializer(serializers.ModelSerializer):
    value_name = serializers.CharField(source="value.name", read_only=True)

    class Meta:
        model = KindnessTask
        fields = ["id", "title", "instruction_text", "value_name"]


class KindnessSubmissionSerializer(serializers.ModelSerializer):
    task = KindnessTaskSerializer(read_only=True)

    class Meta:
        model = KindnessSubmission
        fields = [
            "id", "task", "status", "committed_at",
            "what_i_did_text", "with_whom_text", "result_text",
            "submitted_at", "teacher_status", "teacher_feedback",
        ]
        read_only_fields = fields


class TextAnswerSerializer(serializers.Serializer):
    text = serializers.CharField()


class TeacherFeedbackSerializer(serializers.Serializer):
    feedback_text = serializers.CharField()
