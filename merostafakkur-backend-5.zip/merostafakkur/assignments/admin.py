from django.contrib import admin

from .models import Assignment


@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = ["content_object", "assigned_by", "assigned_to_student", "assigned_to_class", "created_at"]
    list_filter = ["content_type", "assigned_by"]
    autocomplete_fields = ["assigned_by", "assigned_to_student", "assigned_to_class"]
