"""
Har xil kontent turi (HeritageMaterial/MoralDilemma/KindnessTask) uchun
bitta o'quvchining shu topshiriqni qanday bajarganini bir xil interfeys
orqali aniqlaydi.
"""

MODULE_LABELS = {
    "heritagematerial": ("1-modul: Meros izidan", "heritage"),
    "moraldilemma": ("2-modul: Men qanday yo'l tutaman?", "dilemma"),
    "kindnesstask": ("3-modul: Ezgu ishlarim", "kindness"),
}


def get_assignment_status(assignment, student):
    model_name = assignment.content_type.model

    if model_name == "heritagematerial":
        from heritage.models import ValueAnalysisSubmission
        sub = ValueAnalysisSubmission.objects.filter(
            student=student, material_id=assignment.object_id,
        ).first()
    elif model_name == "moraldilemma":
        from dilemmas.models import MoralChoiceSubmission
        sub = MoralChoiceSubmission.objects.filter(
            student=student, dilemma_id=assignment.object_id,
        ).first()
    elif model_name == "kindnesstask":
        from kindness.models import KindnessSubmission
        sub = KindnessSubmission.objects.filter(
            student=student, task_id=assignment.object_id,
        ).first()
    else:
        return "unknown"

    return sub.status if sub else "not_started"


STATUS_LABELS = {
    "not_started": "Boshlanmagan",
    "watching": "Video ko'rilmoqda",
    "answering": "Javob berilmoqda",
    "chose": "Tanlov qilindi",
    "justified": "Asoslandi",
    "committed": "Bajarishga kirishilgan",
    "q1": "Davom etmoqda",
    "q2": "Davom etmoqda",
    "completed": "Bajarildi ✅",
    "unknown": "Noma'lum",
}
