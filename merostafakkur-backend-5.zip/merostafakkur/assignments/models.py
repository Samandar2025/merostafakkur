from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ValidationError
from django.db import models


class Assignment(models.Model):
    """
    O'qituvchi tomonidan biriktirilgan ish — 1, 2 yoki 3-modulning istalgan
    kontent turiga (HeritageMaterial, MoralDilemma, KindnessTask) bir xil
    tarzda ishlaydi, GenericForeignKey orqali.

    Aynan bitta o'quvchiga YOKI bitta sinfga biriktiriladi — ikkalasi birga emas.
    Muddat (deadline) yo'q — istalgan vaqtda bajarish mumkin.
    """

    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="assignments_created",
        limit_choices_to={"role": "teacher"},
    )
    assigned_to_student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True,
        related_name="individual_assignments", limit_choices_to={"role": "student"},
    )
    assigned_to_class = models.ForeignKey(
        "accounts.SchoolClass", on_delete=models.CASCADE, null=True, blank=True,
        related_name="class_assignments",
    )

    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey("content_type", "object_id")

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def clean(self):
        if bool(self.assigned_to_student_id) == bool(self.assigned_to_class_id):
            raise ValidationError(
                "Aynan bittasi tanlanishi kerak: yo alohida o'quvchi, yo sinf (ikkalasi emas, bittasi ham emas)."
            )

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def get_target_students(self):
        """Bu topshiriq amalda kimlarga tegishli ekanini qaytaradi."""
        from accounts.models import User

        if self.assigned_to_student_id:
            return User.objects.filter(id=self.assigned_to_student_id)
        return User.objects.filter(class_memberships__school_class=self.assigned_to_class_id)

    def __str__(self):
        target = self.assigned_to_student or self.assigned_to_class
        return f"{self.content_object} → {target}"
