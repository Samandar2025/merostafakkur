from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Tizimning foydalanuvchilari: o'quvchi va o'qituvchi.
    Django'ning standart AbstractUser'idan meros oladi (username, password va h.k.).
    Alohida "administrator" roli yo'q — o'qituvchi hisobi avtomatik ravishda
    Django admin panelga (/admin/) kirish huquqiga ega bo'ladi, shu orqali
    o'quvchi/sinf/topshiriq boshqaruvini amalga oshiradi.
    """

    class Role(models.TextChoices):
        STUDENT = "student", "O'quvchi"
        TEACHER = "teacher", "O'qituvchi"

    role = models.CharField(max_length=20, choices=Role.choices, default=Role.STUDENT)

    # O'quvchi tizimga login/parol emas, individual kod orqali kirishi mumkin
    # (masalan QR yoki 6 xonali kod). Bu maydon shu maqsad uchun.
    access_code = models.CharField(
        max_length=20, unique=True, null=True, blank=True,
        help_text="O'quvchi kirishi uchun individual kod (login o'rniga)",
    )

    def is_student(self):
        return self.role == self.Role.STUDENT

    def is_teacher(self):
        return self.role == self.Role.TEACHER

    def save(self, *args, **kwargs):
        # O'qituvchi har doim admin panelga kira olishi kerak —
        # buni alohida qadam sifatida qilib o'tirmaslik uchun avtomatik beriladi.
        if self.role == self.Role.TEACHER:
            self.is_staff = True
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.get_role_display()})"


class School(models.Model):
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return self.name


class SchoolClass(models.Model):
    """Sinf, masalan '2-A'."""

    school = models.ForeignKey(School, on_delete=models.CASCADE, related_name="classes")
    name = models.CharField(max_length=50)
    teacher = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="classes_taught", limit_choices_to={"role": User.Role.TEACHER},
    )

    class Meta:
        verbose_name_plural = "School classes"

    def __str__(self):
        return f"{self.school.name} — {self.name}"


class ClassStudent(models.Model):
    """O'quvchi va sinf o'rtasidagi bog'lanish."""

    school_class = models.ForeignKey(SchoolClass, on_delete=models.CASCADE, related_name="students")
    student = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="class_memberships",
        limit_choices_to={"role": User.Role.STUDENT},
    )
    # Tajriba-sinov uchun: eksperimental yoki nazorat guruhi
    group = models.CharField(
        max_length=20,
        choices=[("experimental", "Eksperimental"), ("control", "Nazorat")],
        default="experimental",
    )

    class Meta:
        unique_together = ("school_class", "student")

    def __str__(self):
        return f"{self.student} — {self.school_class}"
