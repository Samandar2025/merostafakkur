from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from .models import ClassStudent, School, SchoolClass, User


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = ["username", "first_name", "last_name", "role", "access_code", "is_active"]
    list_filter = ["role", "is_active"]
    fieldsets = DjangoUserAdmin.fieldsets + (
        ("MerosTafakkur", {"fields": ("role", "access_code")}),
    )


@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    list_display = ["name", "address"]


@admin.register(SchoolClass)
class SchoolClassAdmin(admin.ModelAdmin):
    list_display = ["name", "school", "teacher"]
    list_filter = ["school"]
    search_fields = ["name", "school__name"]


@admin.register(ClassStudent)
class ClassStudentAdmin(admin.ModelAdmin):
    list_display = ["student", "school_class", "group"]
    list_filter = ["school_class", "group"]
